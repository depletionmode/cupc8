# CPU bus and CPU socket (Milestone 1)

The CPU lives on a plug-in **CPU card**. The main board's **chipset** FPGA
answers every CPU bus cycle: from SRAM, from the ROM windows, or from its own
I/O registers (see `memory-map.md`). The CPU card never drives the memory bus.

This bus is the contract between them. The M1 FPGA CPU card and a future
discrete-logic CPU card must both pass the same conformance testbench
(`soc/tb/cpubus_conformance`) against this document.

## Electrical

- **Signalling:** 3.3 V LVCMOS in both directions. The inputs on both sides
  are **not** 5 V tolerant. A 5 V discrete card must level-shift on its own
  side, for example with 74LVC245/74LVC1T45.
- **Pull-ups (main board):** /STB, /CPU_RST, PRSNT2_n and CARD_ID[1:0] have
  10 kΩ to 3V3. So an empty socket reads as "no cycle, no card".
- **Weak keepers:** D[7:0] have a 47 kΩ pull-up on the main board, so a
  floating bus reads `$FF`.
- **Series termination:** every card output has 68 Ω at the card driver
  (RN1-RN8, 4D02WGJ0680TCE C52984), and every chipset CPU-bus output has 56 Ω
  at the chipset (R21-R34, 0603 C25196). Both replace 33 Ω, which overshot the
  iCE40's 3.6 V input limit to 4.2 V (David, 2026-09-29; hw/si/cpubus_options.py).
  The chipset's SPI and BR_MISO outputs stay 33 Ω.

## Clocking

- **CPU_CLK** comes from the main board's 12 MHz oscillator, which drives the
  chipset's CLK12 and the socket's CPU_CLK through a 33 Ω resistor each. The
  two FPGAs therefore see the same edge, apart from trace length. It is the
  only clock the card may use. Both sides sample on its **rising edge**.
- **Frequency:** fixed at 12 MHz in M1. The divider bits in `CPU_CTL` are
  reserved and must be 0. A slower card (such as the M2 discrete CPU) is
  served by /RDY wait states and stop/step, which need no clock change.
- **Stopping:** CPU_CLK never stops while /CPU_RST is high. Stopping and
  stepping are done with /RDY, not by gating the clock.

## Signals

| Signal | Driver | Meaning |
|---|---|---|
| CPU_CLK | main board oscillator | Bus clock |
| /CPU_RST | chipset | Active-low reset. The chipset holds it from power-on until CDONE is high, then for 16 more CPU_CLK edges. The system card can assert it through the bridge (`CPU_CTL` bit 6), and so does the reset button (through the board's reset supervisor). Reset is synchronous: from the first CPU_CLK edge that samples it low, the card must drive /STB high and must not drive D, for as long as it stays low. |
| A[15:0] | card | Address, valid while /STB is low |
| RW | card | 1 = read, 0 = write, valid while /STB is low |
| D[7:0] | both | Data. The card drives it only during write cycles. The chipset drives it only during read cycles, and only in the clock where it asserts /RDY. |
| /STB | card | Cycle request, active low |
| /RDY | chipset | Cycle completion, active low, one clock wide |
| SYNC | card | High during an opcode-fetch cycle: the first byte of an instruction. Not asserted for operand, stack or vector cycles. |
| IRQ[3:0] | chipset | `IRQ_PEND & IRQ_MASK` as levels; line 3 also carries the chipset tick, IRQ_PEND bit 4 (`memory-map.md`, Interrupts). The CPU samples them only at its instruction boundary. |
| TMR_EXP[1:0] | card | A one-clock high pulse when timer 0/1 crosses to zero. The chipset latches it into IRQ_PEND bits 1/2. |
| HALTED | card | High after `HALT` executes, until reset |
| WAITING | card | High while `WAI` is waiting for an IRQ |
| CRESET_n, CDONE, FL1_SCK, FL1_MOSI, FL1_MISO, FL1_nCS | card ↔ system card | The FPGA card's own configuration flash: the FPGA boots from it by itself (SPI master mode). The system card, when fitted, holds CRESET_n low and reprograms the flash through these lines. CDONE also goes to the chipset, which keeps the CPU in reset until it is high. The main board pulls CRESET_n and CDONE up and FL1_nCS up. A card without an FPGA leaves them all unconnected, so it reads as configured. |
| CARD_ID[1:0] | card | Card type, set by straps to GND: `11` = none (pull-ups), `10` = FPGA CPU card, `01` = discrete CPU card, `00` = reserved |
| PRSNT1_n / PRSNT2_n | card | A1 is GND on the main board. The card joins A1 to B49 (PRSNT2_n). The main board sees PRSNT2_n low only when the card is fully seated. |

## Bus cycle

The protocol is a single-master classic handshake, like Wishbone classic with
CYC and STB merged.

- **Request.** At rising edge **n**, the card has put a stable A, RW, SYNC
  (and D for writes) on the bus, with /STB low.
- **Wait states.** The chipset samples /STB low at edge **n**. It asserts /RDY
  low for exactly one clock at some later edge **m ≥ n+1**. Each clock
  between n and m is a wait state, and there can be any number of them.
- **Read data.** In a read, the chipset drives D starting from the same edge
  where /RDY goes low. D is valid at edge **m+1**, when the card samples /RDY
  low and latches D. The chipset stops driving D at edge **m+1**.
- **Write data.** In a write, the card holds D stable from before edge **n**
  until edge **m+1**.
- **End of cycle.** At edge **m+1** the cycle is over. The card may either:
  - raise /STB (idle), or
  - keep /STB low and present a new address, which starts a new cycle that
    the chipset samples at edge **m+1**.

```
edge:       n      n+1     m      m+1
CPU_CLK  _/‾\_/‾\_/‾\_/‾\_/‾\_/‾\_/‾\_
/STB     ‾‾\_________________________/‾   (or stays low: next cycle)
A,RW     ==X=========================X=
/RDY     ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\_______/‾‾‾‾‾‾   one clock wide
D (read) --------------<=======>-------   chipset drives m..m+1
```

**Minimum cycle:** 2 clocks, because /RDY cannot be asserted until the edge
after /STB is sampled. I/O register cycles take 2 clocks.

**SRAM and ROM cycles take 4 clocks** (2 wait states):
1. At the sampling edge, the chipset drives the memory address and chip
   select.
2. The memory then has two full clocks (166 ns) before the chipset registers
   its data. That covers the 70 ns ROM and 45 ns SRAM plus the I/O delays.
3. /RDY is asserted with the registered data.

Writes pulse /WE for one clock (83 ns > tWP), in the middle of the address
window.

**Bus turnaround rule:** the chipset never drives D in the first clock of a
cycle. Every write→read transition therefore has at least one clock with
nobody driving D.

## Instruction boundary, interrupts and timers

- **IRQs.** The CPU samples IRQ[3:0] only between instructions, as it does
  today in `cpu.vhd` `check_irq`. It takes the lowest-numbered one, but not
  right after `POP pcl`: that and the `POP pch` after it are one return
  (an IRQ between them would lose the return address; CPU-005).
- **IRQ entry.** Entry is the push/vector sequence from the manual: push pch,
  push pcl, push f, clear I, read the vector at $0010+2n. Every one of those is
  a normal bus cycle with SYNC low.
- **Timers.** They live on the CPU card, because `TMR0`/`TMR1` are
  instructions. They decrement once per retired instruction, including WAI
  idle iterations, exactly as `cpu.vhd` and `sim.nim` do today.
  - Each timer's `TMR_EXP` pulse goes to the chipset.
  - The chipset latches IRQ_PEND on the rising edge of that pulse.

## Stop, step and trace (chipset + sysctl)

The chipset controls /RDY, so it can control the CPU without the card's
cooperation.

- **Stop.** The chipset stops issuing /RDY. The CPU stalls in whatever cycle
  it is in.
- **Step (instruction).** The chipset completes cycles until it sees the next
  cycle with SYNC high. It holds that cycle un-acknowledged, which leaves the
  CPU stopped at the start of the next instruction.
- **Step (bus cycle).** The chipset completes exactly one cycle.
- **Trace.** Every completed cycle `{A, D, RW, SYNC}` goes into a 512-entry
  BRAM ring. sysctl reads it through the bus bridge. `cupc8.py trace`
  disassembles the SYNC cycles and can diff them against `sim.nim --trace`.
- **While the CPU is stopped,** the bus bridge may use the memory bus. When it
  releases, the chipset resumes by completing the stalled CPU cycle with the
  bus in its normal state. The CPU cannot tell the difference.

Bridge commands, in addition to those in `memory-map.md`. CPU state is read with `$05 STATUS`:

| Cmd | Bytes after cmd | Action |
|---|---|---|
| $07 CPU_CTL | ctl8 | bit0 stop, bit1 step-instruction, bit2 step-cycle, bits 5:3 reserved (0), bit6 assert /CPU_RST |
| $08 TRACE_RD | dummy, → count16, then count × {A16, D8, flags8} | Drain the trace ring, oldest first. count bit 15 = entries were lost since the previous drain. flags: bit0 RW, bit1 SYNC. |

## Timing budget (12 MHz, 83.3 ns period)

`hw/timing/cpubus_budget.py` (BUS-005) checks both directions. It uses the
FPGA I/O delays from nextpnr's place and route of both designs on their real
pins, allowances for what nextpnr does not model (the output pad into the
board load, clock insertion and mismatch, minimum delays), and the board
lengths. Until the boards are laid out, it uses the layout limits: at most
150 mm per CPU bus net across both boards, and at most 50 mm difference
between the two clock traces. Required margin: ≥ 30% of the period.

| Item (ns) | card → chipset | chipset → card |
|---|---|---|
| Launch clock insertion (allowance) | 3.0 | 3.0 |
| Flip-flop to pin (nextpnr) | 5.3 | 6.5 |
| Output pad into ~15 pF (allowance) | 4.0 | 4.0 |
| 150 mm trace, connector, 68 Ω | 3.4 | 3.4 |
| Input pad (allowance) | 0.5 | 0.5 |
| Pin to flip-flop (nextpnr) | 11.6 | 12.1 |
| Setup (allowance) | 0.4 | 0.4 |
| Clock skew: mismatch + 50 mm | 1.4 | 1.4 |
| **Total** | **29.4 → 53.9 slack (65%)** | **31.2 → 52.1 slack (63%)** |

Hold has 1.75 ns of margin: the fastest data path (≥ 3 ns, an allowance)
against the clock skew.

The slow path is the SRAM/ROM access
inside the chipset, which is covered by the wait state rather than by this
budget.

## CPU socket: PCIe x8 card edge

- **Connector:** a 98-contact PCIe x8 vertical socket, 1.0 mm pitch, on the
  main board. The CPU card is a 1.6 mm PCB with 49 gold fingers per side and a
  standard PCIe x8 key.
- **Custom pinout:** it does **not** carry PCIe signalling. Never plug a real
  PCIe card into it. The +5V pins would meet PCIe 12V/3.3V pins wired
  differently.
- **Pin budget:**
  - 5× +5V and 3× +3V3, about 1 A per contact.
  - 34× GND. Every bus signal has a GND on at least one neighbour, and
    CPU_CLK has GND on both neighbours and opposite.
  - 9 reserved pins for M2 (for example microcode-step debug on a discrete
    card).
- **Unused pins:** RSVD pins are left unconnected on both sides. The main
  board routes them to test pads.

| Pin | Side B (component side) | Side A (solder side) |
|---|---|---|
| 1 | +5V | PRSNT1_n |
| 2 | +5V | +5V |
| 3 | +5V | +5V |
| 4 | GND | GND |
| 5 | +3V3 | CRESET_n |
| 6 | +3V3 | CDONE |
| 7 | +3V3 | GND |
| 8 | GND | FL1_SCK |
| 9 | CARD_ID0 | FL1_MOSI |
| 10 | CARD_ID1 | FL1_nCS |
| 11 | GND | GND |
| — | *key* | *key* |
| 12 | GND | GND |
| 13 | CPU_CLK | GND |
| 14 | GND | A0 |
| 15 | GND | GND |
| 16 | /CPU_RST | A1 |
| 17 | /STB | A2 |
| 18 | GND | GND |
| 19 | /RDY | A3 |
| 20 | RW | A4 |
| 21 | GND | GND |
| 22 | SYNC | A5 |
| 23 | D0 | A6 |
| 24 | GND | GND |
| 25 | D1 | A7 |
| 26 | D2 | A8 |
| 27 | GND | GND |
| 28 | D3 | A9 |
| 29 | D4 | A10 |
| 30 | GND | GND |
| 31 | D5 | A11 |
| 32 | D6 | A12 |
| 33 | GND | GND |
| 34 | D7 | A13 |
| 35 | IRQ0 | A14 |
| 36 | GND | GND |
| 37 | IRQ1 | A15 |
| 38 | IRQ2 | FL1_MISO |
| 39 | GND | GND |
| 40 | IRQ3 | RSVD_A2 |
| 41 | TMR_EXP0 | RSVD_A3 |
| 42 | GND | GND |
| 43 | TMR_EXP1 | RSVD_A4 |
| 44 | HALTED | RSVD_A5 |
| 45 | GND | GND |
| 46 | WAITING | RSVD_A6 |
| 47 | RSVD_B1 | RSVD_A7 |
| 48 | GND | GND |
| 49 | PRSNT2_n | RSVD_A8 |

The CPU card may draw up to 500 mA from +3V3 and 1 A from +5V. The M1 FPGA
card draws about 30 mA. See `power.md`.

## CPU card outline

The CPU card has **the same outline as the I/O cards** (`slot.md`,
Mechanical; David, 2026-09-24): the body is x −6.0 … 56.0 mm, y −47.55 …
−4.95 mm in the frame of its finger footprint (finger B1 at the origin), the
M3 hole at (52.0, −43.55) and the power LED at (−3.0, −44.55). Only the tab
differs: the x8 tab (98 contacts, about 50 mm wide) sits under the same body,
where the I/O cards have their x1 tab. On the main board the CPU socket is
first in the row of card sockets, so the CPU card stands in line with the
I/O cards. A later CPU card (the M2 discrete CPU) keeps this outline.

## Conformance testbench (acceptance test for any CPU card)

`soc/tb/cpubus_conformance` drives the card through the socket signals only.
A card passes when all of the following hold.

1. **Protocol monitor:** zero violations. /STB, A, RW and write data are held
   stable until /RDY. D is not driven outside the rules above. Nothing is
   driven during /CPU_RST.
2. **Lockstep:** the completed-cycle trace equals `sim.nim`'s for every
   program in `test/`, `tools/testdata/` and the random-program fuzzer (≥ 10⁶
   instructions). This holds under:
   - 0 wait states, fixed 1–7 wait states, and random 0–15 wait states
   - random stop/step sequences
   - IRQs raised at every clock phase relative to the instruction boundary
   - reset asserted at random points (the CPU must restart cleanly at $e000)
3. **Timing:** at 12 MHz, with the chipset model sampling at ±30% of the
   setup/hold margins.

The 2026-10-01 first article amendment raises the common full top edge by
3.55 mm for a 62 × 51 mm overall card. The CPU’s existing FPGA placement
and routed core remain fixed; the top indicator row and M3 hole follow
the new top edge. Mounting rail supports rise by 3.55 mm (see `slot.md`).
