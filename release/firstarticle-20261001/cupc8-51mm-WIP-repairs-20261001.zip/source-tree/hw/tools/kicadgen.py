"""Generate KiCad schematics and boards from Python descriptions.

KiCad has no scripting API for schematics, so .kicad_sch files are written
as S-expressions. Symbols come from the KiCad libraries and are flattened
(derived symbols merged with their parent), which is how KiCad itself embeds
them. Every connection is a short wire stub from the pin plus a net label,
so a schematic is a set of parts with named nets on their pins.

Boards are built with the pcbnew API from the netlist that kicad-cli exports
from the schematic, so the board can only contain what the schematic says.
"""

import copy
import fnmatch
import math
import os
import re
import subprocess
import uuid as uuidlib

KICAD_SYMBOLS = os.environ.get("KICAD_SYMBOL_DIR", "/usr/share/kicad/symbols")
KICAD_FOOTPRINTS = os.environ.get("KICAD_FOOTPRINT_DIR", "/usr/share/kicad/footprints")
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
HW_LIB = os.path.join(ROOT, "hw", "lib")
PROJECT_FOOTPRINTS = {"cupc8": os.path.join(HW_LIB, "cupc8.pretty"), "jlc": os.path.join(HW_LIB, "jlc.pretty")}
PROJECT_SYMBOLS = {"jlc": os.path.join(HW_LIB, "jlc.kicad_sym"),       # imported by hw/tools/jlcimport.py
                   "cupc8": os.path.join(HW_LIB, "cupc8.kicad_sym"),   # hw/tools/edgesym.py
                   "cupc8_main": os.path.join(HW_LIB, "cupc8_main.kicad_sym")}   # hw/boards/main.py

# 3D models for stock footprints whose model KiCad does not ship, placed from
# the maker's drawing: footprint -> (model under hw/lib/models, offset mm
# (x, y up, z), rotation deg (x, y, z)). check_models() verifies the fit.
MODEL_OVERRIDES = {
    # EasyEDA's model of C165948 (8.94 x 3.25 mm, as the HRO drawing). Its
    # opening is at model y = +2.85; KiCad's footprint has it at y = +3.7
    # facing +y, hence the half turn and the 0.85 mm shift.
    "Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12":
        ("HRO_TYPE-C-31-M-12.wrl", (0, -0.85, 0), (0, 0, 180)),
    # the main board's ROM (C645939): JLC's model of its PLCC-32, whose
    # footprint has KiCad's origin and orientation (pin 1 top centre). A
    # 4th element: how much wider the model is than the fab outline by
    # design (here the J-leads, 12.32 mm across, round an 11.53 mm body)
    "Package_LCC:PLCC-32_11.4x14.0mm_P1.27mm":
        ("../jlc.3dshapes/PLCC-32_L14.0-W11.5-P1.27-T.wrl", (0, 0, 0), (0, 0, 0), 0.8),
}


def symbol_path(lib):
    return PROJECT_SYMBOLS.get(lib) or os.path.join(KICAD_SYMBOLS, lib + ".kicad_sym")


def footprint_dir(lib):
    return PROJECT_FOOTPRINTS.get(lib) or os.path.join(KICAD_FOOTPRINTS, lib + ".pretty")
GRID = 2.54
SCH_VERSION = "20231120"                 # KiCad 8 format; KiCad 10 reads it


# ----------------------------------------------------------- S-expressions

class Q(str):
    """A string that is written quoted."""


_TOKEN = re.compile(r'\s*(?:(\()|(\))|"((?:[^"\\]|\\.)*)"|([^\s()"]+))', re.S)


def parse(text):
    stack, cur = [], []
    pos = 0
    while True:
        m = _TOKEN.match(text, pos)
        if not m or m.end() == pos:
            break
        pos = m.end()
        if m.group(1):
            stack.append(cur)
            cur = []
        elif m.group(2):
            done, cur = cur, stack.pop()
            cur.append(done)
        elif m.group(3) is not None:
            cur.append(Q(re.sub(r'\\(.)', r'\1', m.group(3))))
        else:
            cur.append(m.group(4))
    return cur[0]


def dump(x, indent=0):
    if isinstance(x, list):
        if not any(isinstance(e, list) for e in x):
            return "(" + " ".join(dump(e) for e in x) + ")"
        pad = "\t" * (indent + 1)
        head = [dump(e) for e in x if not isinstance(e, list)]
        out = "(" + " ".join(head)
        for e in x:
            if isinstance(e, list):
                out += "\n" + pad + dump(e, indent + 1)
        return out + "\n" + "\t" * indent + ")"
    if isinstance(x, Q):
        return '"' + x.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(x, float):
        return ("%.4f" % x).rstrip("0").rstrip(".")
    return str(x)


def find(node, key):
    return [e for e in node if isinstance(e, list) and e and e[0] == key]


def find1(node, key):
    r = find(node, key)
    return r[0] if r else None


# UUIDs are derived from a counter, not random: KiCad orders its exports (the
# Specctra DSN among them) by UUID, and a random order gave Freerouting a
# different problem, and a different route, on every run
_UID = uuidlib.UUID("6b1c5a62-1d8e-4c3e-9f0a-c5e8a0d2b7f1")
_uid_n = [0]


def uid():
    _uid_n[0] += 1
    return Q(str(uuidlib.uuid5(_UID, "sch/%d" % _uid_n[0])))


def stable_uuids(board, salt=0):
    """Give every board item a UUID derived from what it is (footprints by
    reference, their pads and graphics by index), replacing the random ones
    pcbnew assigns, so that exports ordered by UUID are the same every run."""
    import pcbnew

    def kiid(key):
        return pcbnew.KIID(str(uuidlib.uuid5(_UID, "%d/%s" % (salt, key) if salt else key)))
    fps = sorted(board.GetFootprints(), key=lambda f: f.GetReference())
    for fp in fps:
        ref = fp.GetReference()
        fp.SetUuidDirect(kiid("fp/" + ref))
        pads = fp.Pads()
        for i in range(len(pads)):
            pads[i].SetUuidDirect(kiid("pad/%s/%d" % (ref, i)))
        gi = fp.GraphicalItems()          # indexed: iterating it breaks on Python 3.14
        for i in range(len(gi)):
            gi[i].SetUuidDirect(kiid("gfx/%s/%d" % (ref, i)))
    for name, items in (("drw", board.Drawings()), ("trk", board.Tracks()), ("zone", board.Zones())):
        for i in range(len(items)):
            items[i].SetUuidDirect(kiid("%s/%d" % (name, i)))


# ----------------------------------------------------------------- symbols

_libs = {}


def _library(name):
    if name not in _libs:
        with open(symbol_path(name)) as f:
            lib = parse(f.read())
        _libs[name] = {s[1]: s for s in find(lib, "symbol")}
    return _libs[name]


def load_symbol(lib_id):
    """The symbol, flattened, named `lib_id` as a schematic embeds it."""
    lib, name = lib_id.split(":")
    syms = _library(lib)
    sym = copy.deepcopy(syms[name])       # the flattening below edits it: keep the cache intact
    parent = find1(sym, "extends")
    if parent:
        base = load_symbol(lib + ":" + parent[1])
        own = {p[1]: p for p in find(sym, "property")}
        # copies: the sub-symbols are renamed below, and `base` shares them
        # with the cached parent (a second symbol extending it, or the same
        # one loaded again in this process, would find them renamed already)
        flat = [copy.deepcopy(e) for e in base if not (isinstance(e, list) and e[0] == "property")]
        props = [own.get(p[1], p) for p in find(base, "property")]
        props += [p for k, p in own.items() if k not in {q[1] for q in props}]
        flat = flat[:2] + props + flat[2:]
        # sub-symbols are named after the symbol
        base_name = str(base[1]).split(":")[-1]
        for e in flat:
            if isinstance(e, list) and e[0] == "symbol":
                e[1] = Q(name + str(e[1])[len(base_name):])
        sym = flat
    sym = [e for e in sym if not (isinstance(e, list) and e[0] == "extends")]
    sym = list(sym)
    sym[1] = Q(lib_id)
    return sym


# --------------------------------------------------------------- schematic
#
# Layout rules, enforced by Schematic.check() on every write:
#   - no text touches other text, a symbol body, a pin or a wire
#   - no two symbol bodies overlap, and no wire crosses another part's body
#   - everything is inside the page frame and clear of the title block
# Reference and Value are placed by Schematic.write in the first free spot
# beside the symbol, so the checker is the only judge of "looks right".

TEXT = 1.27                              # field and label text size
MARGIN = 0.25                            # clearance kept around text
PAGES = {"A4": (297, 210), "A3": (420, 297), "A2": (594, 420), "A1": (841, 594), "A0": (1189, 841)}
FRAME = 10                               # page border
TITLE_BLOCK = (112, 36)                  # bottom-right, width x height


_extents = {}


def text_extent(s, size=TEXT):
    """(width, height) in mm of `s` in KiCad's stroke font, measured by KiCad."""
    if (s, size) not in _extents:
        import pcbnew
        t = pcbnew.PCB_TEXT(pcbnew.BOARD())
        t.SetText(s)
        t.SetTextSize(pcbnew.VECTOR2I(pcbnew.FromMM(size), pcbnew.FromMM(size)))
        t.SetTextThickness(pcbnew.FromMM(size * 0.12))
        bb = t.GetBoundingBox()
        _extents[s, size] = (pcbnew.ToMM(bb.GetWidth()), pcbnew.ToMM(bb.GetHeight()))
    return _extents[s, size]


def text_box(x, y, s, angle=0, hj="center", vj="center", size=TEXT):
    """Axis-aligned box of a text item, angle 0 (horizontal) or 90 (reading up)."""
    w, h = text_extent(s, size)
    a0 = {"left": 0, "right": -w, "center": -w / 2}[hj]
    b0 = {"bottom": -h, "top": 0, "center": -h / 2}[vj]
    if angle % 180 == 0:
        return (x + a0, y + b0, x + a0 + w, y + b0 + h)
    # rotated 90: the text runs up the page, its bottom faces +x
    return (x + b0, y - a0 - w, x + b0 + h, y - a0)


def overlap(a, b, margin=0.0):
    return a[0] < b[2] + margin and b[0] < a[2] + margin and a[1] < b[3] + margin and b[1] < a[3] + margin


def seg_box(x0, y0, x1, y1, width=0.15):
    return (min(x0, x1) - width / 2, min(y0, y1) - width / 2, max(x0, x1) + width / 2, max(y0, y1) + width / 2)


def union(boxes):
    boxes = list(boxes)
    return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))


def _units(sym, unit):
    base = str(sym[1]).split(":")[-1]
    for sub in find(sym, "symbol"):
        m = re.match(re.escape(base) + r"_(\d+)_(\d+)$", str(sub[1]))
        if m and int(m.group(1)) in (0, unit) and int(m.group(2)) in (0, 1):
            yield sub


def symbol_graphics(sym, unit=1):
    """Points of the body outline (symbol coordinates, Y up)."""
    pts = []
    for sub in _units(sym, unit):
        for e in sub:
            if not isinstance(e, list):
                continue
            if e[0] == "rectangle":
                for k in ("start", "end"):
                    p = find1(e, k)
                    pts.append((float(p[1]), float(p[2])))
            elif e[0] in ("polyline", "bezier"):
                pts += [(float(p[1]), float(p[2])) for p in find(find1(e, "pts"), "xy")]
            elif e[0] == "arc":
                pts += [(float(find1(e, k)[1]), float(find1(e, k)[2])) for k in ("start", "mid", "end")]
            elif e[0] == "circle":
                c, r = find1(e, "center"), float(find1(e, "radius")[1])
                pts += [(float(c[1]) - r, float(c[2]) - r), (float(c[1]) + r, float(c[2]) + r)]
    return pts


def symbol_pins(sym, unit=1):
    """{number: (x, y, angle, name, type, length, hidden)} for one unit (style 1)."""
    pins = {}
    for sub in _units(sym, unit):
        for p in find(sub, "pin"):
            at = find1(p, "at")
            ln = find1(p, "length")
            pins[str(find1(p, "number")[1])] = (
                float(at[1]), float(at[2]), float(at[3]) if len(at) > 3 else 0.0,
                str(find1(p, "name")[1]), str(p[1]), float(ln[1]) if ln else 2.54,
                "hide" in p or (find1(p, "hide") or [None, "no"])[1] == "yes")
    return pins


def _hidden(prop):
    if find1(prop, "hide"):
        return find1(prop, "hide")[1] == "yes"
    eff = find1(prop, "effects") or []
    return any(e == "hide" or (isinstance(e, list) and e[0] == "hide" and e[-1] != "no") for e in eff)


def not_in_bom(fpid):
    """True when the footprint marks itself exclude_from_bom (card fingers,
    test pads): the symbol must agree, or DRC's schematic parity fails."""
    if not fpid:
        return False
    lib, name = fpid.split(":")
    with open(os.path.join(footprint_dir(lib), name + ".kicad_mod")) as f:
        attr = re.search(r"\(attr [^)]*\)", f.read())
    return bool(attr and "exclude_from_bom" in attr.group(0))


class Part:
    def __init__(self, sch, lib_id, ref, value, footprint, at, rot, fields, unit):
        self.sch, self.lib_id, self.ref, self.value = sch, lib_id, ref, value
        self.footprint, self.at, self.rot, self.fields, self.unit = footprint, at, rot, fields, unit
        self.uuid = uid()
        self.sym = sch._symbol(lib_id)
        self.pins = symbol_pins(self.sym, unit)
        self.used = {}                   # pin number -> net (None for no-connect)
        props = {str(p[1]): p for p in find(self.sym, "property")}
        self.show = {k: k in props and not _hidden(props[k]) for k in ("Reference", "Value")}
        self.field_at = {}               # field -> (x, y), set by Schematic.write

    def pin(self, key):
        """A pin by number, or by name if the name is unique."""
        key = str(key)
        if key in self.pins:
            return key
        hits = [n for n, p in self.pins.items() if p[3] == key]
        if len(hits) != 1:
            raise KeyError("%s: no single pin %r (have %s)" % (self.ref, key, sorted(self.pins)))
        return hits[0]

    def xf(self, x, y):
        """Symbol coordinates (Y up) to the sheet (Y down), with the part's rotation."""
        r = self.rot % 360
        rx, ry = {0: (x, -y), 90: (-y, -x), 180: (-x, y), 270: (y, x)}[r]
        return self.at[0] + rx, self.at[1] + ry

    def pin_xy(self, num):
        """Sheet position of a pin's connection point, and its outward direction."""
        x, y, ang = self.pins[num][:3]
        # a pin points from its connection point into the body at `ang`
        out = (ang + 180 + self.rot) % 360
        dx, dy = {0: (1, 0), 90: (0, -1), 180: (-1, 0), 270: (0, 1)}[round(out) % 360]
        return self.xf(x, y), (dx, dy)

    def body_box(self):
        pts = [self.xf(x, y) for x, y in symbol_graphics(self.sym, self.unit)]
        return union((x, y, x, y) for x, y in pts) if pts else None

    def pin_boxes(self):
        out = []
        for n, (x, y, ang, _, _, ln, hidden) in self.pins.items():
            if hidden:
                continue
            a = math.radians(ang)
            ex, ey = x + ln * math.cos(a), y + ln * math.sin(a)
            (x0, y0), (x1, y1) = self.xf(x, y), self.xf(ex, ey)
            out.append(seg_box(x0, y0, x1, y1))
        return out

    def number_boxes(self):
        """Pin-number texts: centred along the pin, just above (or left of) it."""
        if find1(self.sym, "pin_numbers") and "hide" in str(find1(self.sym, "pin_numbers")):
            return []
        out = []
        for n, (x, y, ang, _, _, ln, hidden) in self.pins.items():
            if hidden:
                continue
            a = math.radians(ang)
            (x0, y0), (x1, y1) = self.xf(x, y), self.xf(x + ln * math.cos(a), y + ln * math.sin(a))
            mx, my = (x0 + x1) / 2, (y0 + y1) / 2
            if abs(y0 - y1) < 1e-6:          # horizontal pin: number above it
                out.append((text_box(mx, my - 0.25, n, 0, "center", "bottom"), n))
            else:                            # vertical: reads up, left of the pin
                out.append((text_box(mx - 0.25, my, n, 90, "center", "bottom"), n))
        return out

    def extent(self):
        boxes = self.pin_boxes() + ([self.body_box()] if self.body_box() else [])
        return union(boxes)

    def field_boxes(self):
        """Boxes of the visible Reference/Value texts, once placed."""
        out = []
        for k, text in (("Reference", self.ref), ("Value", self.value)):
            if self.show[k] and k in self.field_at:
                out.append(text_box(*self.field_at[k], text))
        return out


class Schematic:
    def __init__(self, project, title="", paper="A3"):
        self.project, self.title, self.paper = project, title, paper
        self.uuid = uid()
        self.parts = []
        self.syms = {}
        self.items = []
        self.wires = []                  # (x0, y0, x1, y1, part, net)
        self.labels = []                 # (box, text, part)
        self.ncs = []                    # (box, part): no-connect crosses

    def _symbol(self, lib_id):
        if lib_id not in self.syms:
            self.syms[lib_id] = load_symbol(lib_id)
        return self.syms[lib_id]

    def add(self, lib_id, ref, value, footprint="", at=(0, 0), rot=0, fields=None, unit=1):
        p = Part(self, lib_id, ref, value, footprint, at, rot, fields or {}, unit)
        self.parts.append(p)
        return p

    def _stacked(self, part, num):
        """Pins of `part` at the same point as `num` (stacked pins, one connection)."""
        here = part.pin_xy(num)[0]
        return [n for n in part.pins if part.pin_xy(n)[0] == here]

    def connect(self, part, pin, net, stub=2 * GRID):
        num = part.pin(pin)
        if num in part.used:
            if part.used[num] != net:
                raise ValueError("%s pin %s is on %s, not %s" % (part.ref, num, part.used[num], net))
            return                       # a stacked pin already drawn
        for n in self._stacked(part, num):
            part.used[n] = net
        (x, y), (dx, dy) = part.pin_xy(num)
        ex, ey = round(x + dx * stub, 4), round(y + dy * stub, 4)
        self.items.append(["wire", ["pts", ["xy", x, y], ["xy", ex, ey]],
                           ["stroke", ["width", 0], ["type", "default"]], ["uuid", uid()]])
        self.wires.append((x, y, ex, ey, part, net))
        angle = {(1, 0): 0, (0, -1): 90, (-1, 0): 180, (0, 1): 270}[(dx, dy)]
        justify = {0: "left", 90: "left", 180: "right", 270: "right"}[angle]
        self.items.append(["label", Q(net), ["at", ex, ey, angle % 180],
                           ["fields_autoplaced", "yes"],
                           ["effects", ["font", ["size", TEXT, TEXT]], ["justify", justify, "bottom"]],
                           ["uuid", uid()]])
        # the text sits just off the wire, running away from the pin
        box = text_box(ex, ey, net, angle % 180, justify, "bottom")
        off = 0.3                        # KiCad lifts label text off the wire
        box = (box[0], box[1] - off, box[2], box[3] - off) if angle % 180 == 0 else \
              (box[0] - off, box[1], box[2] - off, box[3])
        self.labels.append((box, net, part))

    def nc(self, part, pin, stub=0):
        """A no-connect cross on the pin, or `stub` mm out on a wire from it:
        short library pins (KiCad's FPGA symbols) leave no room for the cross
        beside the pin number."""
        num = part.pin(pin)
        for n in self._stacked(part, num):
            part.used[n] = None
        (x, y), (dx, dy) = part.pin_xy(num)
        if stub:
            ex, ey = round(x + dx * stub, 4), round(y + dy * stub, 4)
            self.items.append(["wire", ["pts", ["xy", x, y], ["xy", ex, ey]],
                               ["stroke", ["width", 0], ["type", "default"]], ["uuid", uid()]])
            self.wires.append((x, y, ex, ey, part, None))
            x, y = ex, ey
        self.items.append(["no_connect", ["at", x, y], ["uuid", uid()]])
        self.ncs.append(((x - 0.65, y - 0.65, x + 0.65, y + 0.65), part))

    def unconnected(self):
        return [(p.ref, n) for p in self.parts for n in p.pins if n not in p.used]

    # ---- layout

    def _page(self):
        w, h = PAGES[self.paper]
        drawable = (FRAME, FRAME, w - FRAME, h - FRAME)
        title = (w - FRAME - TITLE_BLOCK[0], h - FRAME - TITLE_BLOCK[1], w - FRAME, h - FRAME)
        return drawable, title

    def _obstacles(self, skip_fields_of=None):
        """(box, kind, part) for everything drawn."""
        obs = []
        for p in self.parts:
            b = p.body_box()
            if b:
                obs.append((b, "body", p))
            obs += [(pb, "pin", p) for pb in p.pin_boxes()]
            if p is not skip_fields_of:
                obs += [(fb, "text", p) for fb in p.field_boxes()]
            obs += [(nb, "number", p) for nb, _ in p.number_boxes()]
        obs += [(seg_box(*w[:4]), "wire", w[4]) for w in self.wires]
        obs += [(box, "text", part) for box, _, part in self.labels]
        obs += [(box, "nc", part) for box, part in self.ncs]
        return obs

    def _place_fields(self, p):
        texts = [(k, t) for k, t in (("Reference", p.ref), ("Value", p.value)) if p.show[k]]
        if not texts:
            return
        pitch = text_extent("X")[1] + 0.2
        w = max(text_extent(t)[0] for _, t in texts)
        h = pitch * len(texts)
        x0, y0, x1, y1 = p.extent()
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        gap = GRID / 2
        # sides with no pins first: text there never crowds wiring
        pin_sides = {p.pin_xy(n)[1] for n, pin in p.pins.items() if not pin[6]}
        sides = [(1, 0), (0, -1), (-1, 0), (0, 1)]          # right, above, left, below
        sides = [d for d in sides if d not in pin_sides] + [d for d in sides if d in pin_sides]
        spots = []
        for dx, dy in sides:
            for shift in (0, GRID, -GRID, 2 * GRID, -2 * GRID, 3 * GRID, -3 * GRID):
                if dx:
                    spots.append((x1 + gap + w / 2 if dx > 0 else x0 - gap - w / 2, cy + shift))
                else:
                    spots.append((cx + shift, y0 - gap - h / 2 if dy < 0 else y1 + gap + h / 2))
        drawable, title = self._page()
        obs = [b for b, _, q in self._obstacles(skip_fields_of=p)]
        for sx, sy in spots:
            at = {k: (sx, sy + (i - (len(texts) - 1) / 2) * pitch) for i, (k, _) in enumerate(texts)}
            boxes = [text_box(*at[k], t) for k, t in texts]
            if all(not overlap(b, o, MARGIN) for b in boxes for o in obs) and \
               all(drawable[0] <= b[0] and b[2] <= drawable[2] and drawable[1] <= b[1] and b[3] <= drawable[3]
                   and not overlap(b, title) for b in boxes):
                p.field_at = {k: (round(v[0], 3), round(v[1], 3)) for k, v in at.items()}
                return
        raise ValueError("%s: no free spot for its reference and value; move it" % p.ref)

    def check(self):
        """Every layout rule; returns a list of problems (empty = clean)."""
        bad = []
        obs = self._obstacles()
        drawable, title = self._page()
        texts = [(b, p) for b, k, p in obs if k == "text"]
        for i, (a, pa) in enumerate(texts):
            for b, pb in texts[i + 1:]:
                if overlap(a, b):
                    bad.append("text overlaps text near (%.1f, %.1f) [%s/%s]" % (a[0], a[1], pa.ref, pb.ref))
            for b, kind, q in obs:
                if kind in ("body", "pin", "wire", "nc", "number") and overlap(a, b, -0.02):
                    bad.append("text of %s overlaps a %s of %s near (%.1f, %.1f)" % (pa.ref, kind, q.ref, a[0], a[1]))
        # a pin number must fit along its pin (not run into the body) and
        # clear everything else drawn
        for p in self.parts:
            body = p.body_box()
            for nb, n in p.number_boxes():
                if body and overlap(nb, body, -0.02):
                    bad.append("pin number %s of %s runs into its body (pin too short)" % (n, p.ref))
                for b, kind, q in obs:
                    if kind in ("text", "nc", "wire") and overlap(nb, b, -0.02) and not (kind == "wire" and q is p):
                        bad.append("pin number %s of %s overlaps a %s of %s" % (n, p.ref, kind, q.ref))
        bodies = [(b, p) for b, k, p in obs if k == "body"]
        for i, (a, pa) in enumerate(bodies):
            for b, pb in bodies[i + 1:]:
                if overlap(a, b):
                    bad.append("bodies of %s and %s overlap" % (pa.ref, pb.ref))
        # KiCad joins wires that touch, so two nets' stubs must never meet
        for i, w in enumerate(self.wires):
            for v in self.wires[i + 1:]:
                if w[5] != v[5] and overlap(seg_box(*w[:4], width=0), seg_box(*v[:4], width=0), 0.01):
                    bad.append("wires of %s (%s) and %s (%s) touch: a short" % (w[4].ref, w[5], v[4].ref, v[5]))
        for w in self.wires:
            for b, pb in bodies:
                if pb is not w[4] and overlap(seg_box(*w[:4]), b):
                    bad.append("wire from %s crosses the body of %s" % (w[4].ref, pb.ref))
        for b, kind, p in obs:
            if not (drawable[0] <= b[0] and b[2] <= drawable[2] and drawable[1] <= b[1] and b[3] <= drawable[3]):
                bad.append("%s of %s is outside the page frame" % (kind, p.ref))
            elif overlap(b, title):
                bad.append("%s of %s is on the title block" % (kind, p.ref))
        return sorted(set(bad))

    def _instance(self, p):
        props = []
        fields = [("Reference", p.ref), ("Value", p.value), ("Footprint", p.footprint)]
        fields += list(p.fields.items())
        # KiCad draws a field's angle relative to the symbol: 90 on a quarter-
        # turned part is horizontal on the sheet
        fa = 90 if p.rot % 180 else 0
        for k, v in fields:
            x, y = p.field_at.get(k, p.at)
            shown = k in p.field_at and p.show.get(k, False)
            props.append(["property", Q(k), Q(v), ["at", x, y, fa],
                          ["effects", ["font", ["size", TEXT, TEXT]]] + ([] if shown else [["hide", "yes"]])])
        return (["symbol", ["lib_id", Q(p.lib_id)], ["at", p.at[0], p.at[1], p.rot], ["unit", p.unit],
                 ["exclude_from_sim", "no"], ["in_bom", "no" if not_in_bom(p.footprint) else "yes"],
                 ["on_board", "yes"], ["dnp", "no"],
                 ["uuid", p.uuid]] + props +
                [["pin", Q(n), ["uuid", uid()]] for n in p.pins] +
                [["instances", ["project", Q(self.project),
                                ["path", Q("/" + self.uuid), ["reference", Q(p.ref)], ["unit", p.unit]]]]])

    def write_lib_tables(self, outdir, footprints=()):
        """Project library tables for every library this design uses, so the
        project opens the same way with or without global KiCad setup."""
        syms = sorted({p.lib_id.split(":")[0] for p in self.parts})
        fps = sorted({p.footprint.split(":")[0] for p in self.parts if p.footprint} | set(footprints))
        with open(os.path.join(outdir, "sym-lib-table"), "w") as f:
            f.write(dump(["sym_lib_table", ["version", 7]] +
                         [["lib", ["name", Q(n)], ["type", Q("KiCad")],
                           ["uri", Q(symbol_path(n))],
                           ["options", Q("")], ["descr", Q("")]] for n in syms]) + "\n")
        with open(os.path.join(outdir, "fp-lib-table"), "w") as f:
            f.write(dump(["fp_lib_table", ["version", 7]] +
                         [["lib", ["name", Q(n)], ["type", Q("KiCad")],
                           ["uri", Q(footprint_dir(n))],
                           ["options", Q("")], ["descr", Q("")]] for n in fps]) + "\n")

    def write(self, path, footprint_libs=()):
        """Place the fields, check the layout, and write the sheet.
        footprint_libs: extra libraries the board uses (logos and such)."""
        for p in self.parts:
            self._place_fields(p)
        bad = self.check()
        if bad:
            raise ValueError("schematic layout:\n  " + "\n  ".join(bad))
        self.write_lib_tables(os.path.dirname(os.path.abspath(path)), footprint_libs)
        doc = (["kicad_sch", ["version", SCH_VERSION], ["generator", Q("cupc8-kicadgen")],
                ["uuid", self.uuid], ["paper", Q(self.paper)],
                ["title_block", ["title", Q(self.title)]],
                ["lib_symbols"] + list(self.syms.values())] +
               self.items + [self._instance(p) for p in self.parts] +
               [["sheet_instances", ["path", Q("/"), ["page", Q("1")]]]])
        with open(path, "w") as f:
            f.write(dump(doc) + "\n")


# ----------------------------------------------------------------- netlist

def export_netlist(sch_path, out_path):
    run(["kicad-cli", "sch", "export", "netlist", "--format", "kicadsexpr", "-o", out_path, sch_path])
    with open(out_path) as f:
        net = parse(f.read())
    comps = {}
    for c in find(find1(net, "components"), "comp"):
        ts = find1(c, "tstamps") or find1(c, "tstamp")
        comps[str(find1(c, "ref")[1])] = {
            "value": str(find1(c, "value")[1]),
            "footprint": str(find1(c, "footprint")[1]) if find1(c, "footprint") else "",
            "uuid": str(ts[1]),
            "fields": {str(f[1][1]): str(f[2]) for f in find(find1(c, "fields") or [], "field")
                       if len(f) > 2},
        }
    nets = {}
    for n in find(find1(net, "nets"), "net"):
        name = str(find1(n, "name")[1])
        nets[name] = [(str(find1(nd, "ref")[1]), str(find1(nd, "pin")[1])) for nd in find(n, "node")]
    return comps, nets


# ----------------------------------------------------------------- project

SOLDER_MASK_WEB = 0.1  # mm; also checked on plotted F/B mask openings
SOLDER_MASK_EXPANSION = 0.01  # KiCad's region plot needs a little opening margin over pad copper

# JLCPCB standard capabilities are 0.127 mm track/space (2-layer), 0.3 mm via
# drill, 0.3 mm copper to edge; these rules keep a margin above them.
JLC_RULES = {
    "min_track_width": 0.15,
    "min_clearance": 0.15,
    "min_via_diameter": 0.6,
    "min_through_hole_diameter": 0.3,
    "min_via_annular_width": 0.13,
    "min_copper_edge_clearance": 0.3,
    "min_hole_clearance": 0.25,
    "min_hole_to_hole": 0.5,
    "min_solder_mask_web": SOLDER_MASK_WEB,
    "min_connection": 0.15,
    "min_resolved_spokes": 2,
    "min_silk_clearance": 0.0,
    "min_text_height": 0.8,
    "min_text_thickness": 0.15,
    "max_error": 0.005,
}

# JLC's 4-layer capability is finer (0.09 mm track and space): Freerouting
# necks a Fine track down to 0.11 mm where it meets a fine-pitch pad, and
# 0.075 mm onto a finger's stub, which the 2-layer minimum would refuse
JLC_RULES_4 = {"min_track_width": 0.1, "min_connection": 0.1}

NET_CLASSES = [
    # name, track, clearance, via diameter, via drill
    ("Default", 0.2, 0.2, 0.6, 0.3),        # 0.2: two 0.6/0.3 vias then keep holes 0.5 apart (JLC)
    ("Power", 0.5, 0.2, 0.8, 0.4),
    # nets on a 0.4 mm-pitch part (the RP2040's QFN-56): its pads are 0.2 mm
    # apart, so at 0.2 mm clearance Freerouting counts every neighbouring pair
    # a violation and routes none of them. 0.15 mm track and clearance (JLC's
    # minimum is 0.1, and min_clearance above is 0.15). Its vias are 0.7 mm,
    # so one 0.15 mm from a 0.6 mm Default via keeps the holes 0.5 mm apart (JLC).
    ("Fine", 0.15, 0.15, 0.7, 0.3),
]
# power nets on a fine-pitch part (the main board's eFuse QFN): Power's track
# and via, Fine's clearance (its pins are 0.15-0.19 mm apart). Only in a
# project given fine_power_nets.
FINE_POWER_CLASS = ("FinePower", 0.5, 0.15, 0.8, 0.4)


def write_project(path, power_nets=(), rules=None, fine_nets=(), fine_power_nets=(), dense_nets=()):
    """A .kicad_pro with the design rules and net classes kicad-cli DRC uses."""
    import json
    classes = [{"name": n, "track_width": w, "clearance": c, "via_diameter": vd, "via_drill": vdr,
                "diff_pair_width": 0.2, "diff_pair_gap": 0.2, "diff_pair_via_gap": 0.25,
                "microvia_diameter": 0.3, "microvia_drill": 0.1, "bus_width": 12, "wire_width": 6,
                "line_style": 0, "pcb_color": "rgba(0, 0, 0, 0.000)",
                "schematic_color": "rgba(0, 0, 0, 0.000)", "priority": 2147483647 if n == "Default" else 0}
               for n, w, c, vd, vdr in NET_CLASSES + ([FINE_POWER_CLASS] if fine_power_nets else []) +
               ([("DenseSignal", 0.1, 0.1, 0.7, 0.3)] if dense_nets else [])]
    pro = {
        "board": {"design_settings": {
            "rules": dict(JLC_RULES, **(rules or {}), **({"min_clearance": 0.1} if dense_nets else {})),
            # boards are regenerated from the libraries on every run, so they
            # cannot drift from them; the only differences are the deliberate
            # edits here (designators placed, silkscreen trimmed to the edge)
            "rule_severities": {"lib_footprint_mismatch": "ignore"},
        }},
        "net_settings": {"classes": classes, "meta": {"version": 4},
                         "netclass_patterns": [{"netclass": "Power", "pattern": n} for n in power_nets] +
                                              [{"netclass": "Fine", "pattern": n} for n in fine_nets] +
                                              [{"netclass": "FinePower", "pattern": n} for n in fine_power_nets] +
                                              [{"netclass": "DenseSignal", "pattern": n} for n in dense_nets]},
        "meta": {"filename": os.path.basename(path), "version": 3},
    }
    with open(path, "w") as f:
        json.dump(pro, f, indent=2)


# ------------------------------------------------------------------- board

def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise RuntimeError("%s failed (%d):\n%s%s" % (cmd[0], r.returncode, r.stdout, r.stderr))
    return r


LOGO = "KaplanLabs_Logo"                 # the logo footprints hw/tools/logo.py writes


def silk_keepout(board, fp, margin=0.3):
    """A rule area with no tracks and no vias on the artwork's copper side
    (F.Cu for top silkscreen) over a board-only graphic (the logo): a track
    under it shows through the mask as a ridge across the artwork. The
    pour still fills under it, so the artwork sits on even copper."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    bb = fp.GetBoundingBox(False)
    x0, y0 = to(bb.GetLeft()) - margin, to(bb.GetTop()) - margin
    x1, y1 = to(bb.GetRight()) + margin, to(bb.GetBottom()) + margin
    z = pcbnew.ZONE(board)
    z.SetIsRuleArea(True)
    z.SetZoneName("logo")
    z.SetDoNotAllowTracks(True)
    z.SetDoNotAllowVias(True)
    z.SetDoNotAllowPads(False)
    z.SetDoNotAllowZoneFills(False)
    z.SetDoNotAllowFootprints(False)
    z.SetLayer(pcbnew.B_Cu if fp.IsFlipped() else pcbnew.F_Cu)
    ol = z.Outline()
    ol.NewOutline()
    for px, py in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)):
        ol.Append(mm(px), mm(py))
    board.Add(z)


def normalize_silk_strokes(board, minimum_mm=0.15):
    """Widen printable footprint strokes; move pad-adjacent fragments to Fab.

    Stock footprints commonly use 0.10/0.12 mm outlines. Filled polygons have
    zero stroke and need a separate minimum-ink-width check. A stock passive
    outline may end exactly at the old width's pad clearance; widening that
    fragment would print over the pad. Its Fab outline remains available for
    assembly when the fragment cannot fit on silkscreen.
    """
    import pcbnew
    minimum = pcbnew.FromMM(minimum_mm)
    to = pcbnew.ToMM
    pads = []
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            box = pad.GetBoundingBox()
            pads.append((to(box.GetLeft()), to(box.GetTop()), to(box.GetRight()),
                         to(box.GetBottom()), pad.IsOnLayer(pcbnew.F_Cu),
                         pad.IsOnLayer(pcbnew.B_Cu)))

    def would_touch_pad(segment, front):
        a, b = segment.GetStart(), segment.GetEnd()
        ax, ay, bx, by = to(a.x), to(a.y), to(b.x), to(b.y)
        dx, dy = bx - ax, by - ay
        pad_margin = minimum_mm / 2 + 0.15 + 0.01
        for x0, y0, x1, y1, on_f, on_b in pads:
            if not (on_f if front else on_b):
                continue
            lo, hi = 0.0, 1.0
            for p, q in ((-dx, ax - x0 + pad_margin), (dx, x1 + pad_margin - ax),
                         (-dy, ay - y0 + pad_margin), (dy, y1 + pad_margin - ay)):
                if p == 0:
                    if q < 0:
                        lo, hi = 1.0, 0.0
                elif p < 0:
                    lo = max(lo, q / p)
                else:
                    hi = min(hi, q / p)
            if hi > lo:
                return True
        return False

    def round_mark_would_touch_pad(mark, front):
        # A pin-one dot is a circle, not a segment. Its old bounding box
        # includes the old stroke; grow it by the width increase and the
        # required mask clearance before deciding whether it can be widened.
        box = mark.GetBoundingBox()
        box.Inflate(pcbnew.FromMM(0.15 + (minimum_mm - to(mark.GetWidth())) / 2 + 0.01))
        x0, y0, x1, y1 = (to(box.GetLeft()), to(box.GetTop()),
                          to(box.GetRight()), to(box.GetBottom()))
        return any((on_f if front else on_b) and x0 < px1 and px0 < x1 and
                   y0 < py1 and py0 < y1
                   for px0, py0, px1, py1, on_f, on_b in pads)

    changed = 0
    for fp in board.GetFootprints():
        graphics = fp.GraphicalItems()
        # KiCad 10's Python 3.14 SWIG iterator lacks next(); indexing works.
        for index in range(graphics.size()):
            item = graphics[index].Cast()
            if item.GetLayer() not in (pcbnew.F_SilkS, pcbnew.B_SilkS) or not hasattr(item, "GetWidth"):
                continue
            width = item.GetWidth()
            if 0 < width < minimum:
                if (isinstance(item, pcbnew.PCB_SHAPE) and
                        ((item.GetShape() == pcbnew.SHAPE_T_SEGMENT and
                          would_touch_pad(item, item.GetLayer() == pcbnew.F_SilkS)) or
                         (item.GetShape() == pcbnew.SHAPE_T_CIRCLE and
                          round_mark_would_touch_pad(item, item.GetLayer() == pcbnew.F_SilkS)))):
                    item.SetLayer(pcbnew.F_Fab if item.GetLayer() == pcbnew.F_SilkS
                                  else pcbnew.B_Fab)
                else:
                    item.SetWidth(minimum)
                changed += 1
    return changed


def build_board(comps, nets, placement, outline, layers=2, zones=("GND",), graphics=(), edge=None,
                zone_outline=None, labels=None, plane=False, silk_text=None, logo_keepout=False,
                label_side=None, power_nets=(), designator_reach=None):
    """A pcbnew BOARD with every footprint placed and every pad on its net.

    placement: {ref: (x_mm, y_mm, rot_deg[, "B" for the bottom side])}
    outline:   (x0, y0, x1, y1) in mm
    graphics:  board-only footprints such as logos: ("lib:name", x, y, rot)
    zones:     nets poured on F.Cu and B.Cu, or (net, (layer names)) for
               chosen layers; an inner layer with a zone becomes a plane
    edge:      Edge.Cuts as an open polyline [(x, y), ...] in place of the
               outline rectangle - for a card whose edge-connector footprint
               draws its own tab. Silk, designators and zones still keep
               inside `outline`, the card body.
    zone_outline: the copper pours' polygon, if not `outline` less 0.5 mm
    labels:    {ref: word}: the word (what an LED shows) printed where the part's
               designator would go, in its place
    logo_keepout: no tracks or vias on the copper under the logo (silk_keepout)
    power_nets: net-name patterns of the power class (write_project): with the
               pour nets, they keep solid pad connections (relieve_chip_pads)
    """
    import pcbnew
    mm = pcbnew.FromMM
    board = pcbnew.BOARD()
    board.SetCopperLayerCount(layers)
    # fabcheck reads this saved-board rule when checking the plotted masks.
    board.GetDesignSettings().m_SolderMaskMinWidth = mm(SOLDER_MASK_WEB)
    board.GetDesignSettings().m_SolderMaskExpansion = mm(SOLDER_MASK_EXPANSION)

    netinfo = {}
    for name in nets:
        ni = pcbnew.NETINFO_ITEM(board, name)
        board.Add(ni)
        netinfo[name] = ni
    pad_net = {(r, p): n for n, nodes in nets.items() for r, p in nodes}

    for ref, c in comps.items():
        lib, name = c["footprint"].split(":")
        fp = pcbnew.FootprintLoad(footprint_dir(lib), name)
        if fp is None:
            raise KeyError("%s: footprint %s not found" % (ref, c["footprint"]))
        override = MODEL_OVERRIDES.get(c["footprint"])
        if override:
            m = pcbnew.FP_3DMODEL()
            m.m_Filename = os.path.join(HW_LIB, "models", override[0])
            m.m_Offset = pcbnew.VECTOR3D(*override[1])
            m.m_Rotation = pcbnew.VECTOR3D(*override[2])
            fp.Models().clear()
            fp.Models().push_back(m)
        models = fp.Models()                 # index it: iterating yields copies
        for i in range(len(models)):         # imported parts: ${CUPC8_LIB}/jlc.3dshapes/...
            models[i].m_Filename = models[i].m_Filename.replace("${CUPC8_LIB}", HW_LIB)
        fp.SetReference(ref)
        fp.SetValue(c["value"])
        fp.SetFPID(pcbnew.LIB_ID(lib, name))
        fp.SetPath(pcbnew.KIID_PATH("/" + c["uuid"]))
        for k, v in c["fields"].items():
            if k not in ("Footprint", "Datasheet", "Description"):
                fp.SetField(k, v)
                fp.GetField(k).SetVisible(False)   # LCSC etc. are data, not silkscreen
        if ref not in placement:
            raise KeyError("%s has no placement" % ref)
        x, y, rot, *side = placement[ref]
        board.Add(fp)
        if side and side[0] == "B":
            fp.Flip(fp.GetPosition(), pcbnew.FLIP_DIRECTION_TOP_BOTTOM)
        fp.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
        fp.SetOrientationDegrees(rot)
        for pad in fp.Pads():
            n = pad_net.get((ref, pad.GetNumber()))
            if n:
                pad.SetNet(netinfo[n])

    for i, (fpid, x, y, rot) in enumerate(graphics):
        lib, name = fpid.split(":")
        fp = pcbnew.FootprintLoad(footprint_dir(lib), name)
        if fp is None:
            raise KeyError("footprint %s not found" % fpid)
        fp.SetReference("G%d" % (i + 1))
        fp.SetFPID(pcbnew.LIB_ID(lib, name))
        board.Add(fp)
        fp.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
        fp.SetOrientationDegrees(rot)
        if logo_keepout and name.startswith(LOGO):
            silk_keepout(board, fp)

    x0, y0, x1, y1 = outline
    corners = edge or [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    for a, b in zip(corners, corners[1:]):
        seg = pcbnew.PCB_SHAPE(board)
        seg.SetShape(pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(pcbnew.VECTOR2I(mm(a[0]), mm(a[1])))
        seg.SetEnd(pcbnew.VECTOR2I(mm(b[0]), mm(b[1])))
        seg.SetLayer(pcbnew.Edge_Cuts)
        seg.SetWidth(mm(0.1))
        board.Add(seg)

    clip_silk_to_board(board, outline)
    clip_silk_to_pads(board)
    place_designators(board, outline, labels or {}, silk_text=silk_text, label_side=label_side, reach_mm=designator_reach)

    copper = [pcbnew.F_Cu, pcbnew.B_Cu]
    if plane and layers == 4:
        # plane=True (the system card): the outer layers' pour on In1.Cu too,
        # which stays a signal layer (as a power layer a QFN-56 fan-out no
        # longer routed) and fills what the routes leave. A (net, layers)
        # zone instead (the CPU card) makes the named inner layers planes.
        copper.append(pcbnew.In1_Cu)
    outer = [pcbnew.F_Cu, pcbnew.B_Cu]
    for zone in zones:
        # a zone is a net on the pour layers above, or (net, ("In1.Cu", ...)):
        # inner layers named that way become planes (power layers), which
        # Freerouting reaches with vias and never routes signals on; with a
        # third element "routed", (net, ("In2.Cu",), "routed"), the layer keeps
        # carrying signals and the pour is filled round them after routing
        net, names = (zone, None) if isinstance(zone, str) else zone[:2]
        routed = not isinstance(zone, str) and len(zone) > 2 and zone[2] == "routed"
        layers = [board.GetLayerID(n) for n in names] if names else copper
        for layer in layers:
            if names and layer not in outer and not routed:
                board.SetLayerType(layer, pcbnew.LT_POWER)
            z = pcbnew.ZONE(board)
            z.SetLayer(layer)
            z.SetNet(netinfo[net])
            z.SetLocalClearance(mm(0.3))
            z.SetMinThickness(mm(0.25))
            z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL)   # solid: fine for reflow, no starved spokes
            z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)   # no floating copper
            ol = z.Outline()
            ol.NewOutline()
            for px, py in zone_outline or ((x0 + .5, y0 + .5), (x1 - .5, y0 + .5), (x1 - .5, y1 - .5),
                                           (x0 + .5, y1 - .5)):
                ol.Append(mm(px), mm(py))
            board.Add(z)
    relieve_chip_pads(board, [z if isinstance(z, str) else z[0] for z in zones], power_nets)
    return board


def relieve_chip_pads(board, pour_nets, power_nets, spoke_mm=0.25, gap_mm=0.3):
    """Thermal-relief the pour connection of a small two-pad SMD part's pad
    that sits in a pour while its other pad is on a signal track: the
    tombstoning case in jlc-assembly-dfm-audit-20260928.md (I1), where the
    solid pad heats slowly and the free pad's paste pulls the part up.
    Everything else stays ZONE_CONNECTION_FULL, as the audit asks: exposed
    and multi-pad parts (ICs, modules, connectors), and any part whose other
    pad is on a pour net or a power-class net (decoupling and power paths
    keep their low inductance). Spokes are `spoke_mm` wide. Returns the pads
    relieved."""
    import pcbnew
    for z in board.Zones():
        z.SetThermalReliefSpokeWidth(pcbnew.FromMM(spoke_mm))
        z.SetThermalReliefGap(pcbnew.FromMM(gap_mm))
    pour = set(pour_nets)

    def rail(name):
        return name in pour or any(fnmatch.fnmatchcase(name, pat) for pat in power_nets)

    relieved = 0
    for fp in board.GetFootprints():
        pads = list(fp.Pads())
        if len(pads) != 2 or not fp.GetAttributes() & pcbnew.FP_SMD:
            continue
        if any(max(pcbnew.ToMM(p.GetSize().x), pcbnew.ToMM(p.GetSize().y)) > 2.0 for p in pads):
            continue
        names = [p.GetNetname() for p in pads]
        for pad, other in ((pads[0], names[1]), (pads[1], names[0])):
            if pad.GetNetname() in pour and other and not rail(other):
                pad.SetLocalZoneConnection(pcbnew.ZONE_CONNECTION_THERMAL)
                relieved += 1
    return relieved


def card_zone(body, tab, reach):
    """A card's pour outline: the body less 0.5 mm, plus the finger tab
    (x from tab[0] to tab[1]) down to y = `reach`, over the top ends of the
    fingers, so the GND fingers join the pour (clearance keeps it out from
    between them). `body` ends where the tab starts."""
    x0, y0, x1, y1 = body
    tx0, tx1 = tab
    return [(x0 + .5, y0 + .5), (x1 - .5, y0 + .5), (x1 - .5, y1 - .5), (tx1 - .5, y1 - .5),
            (tx1 - .5, reach), (tx0 + .5, reach), (tx0 + .5, y1 - .5), (x0 + .5, y1 - .5)]


def clip_silk_to_board(board, outline, gap=0.15):
    """Trim footprint silkscreen to the board: a connector that overhangs the
    edge (as its maker intends) has outline lines that cannot be printed.
    Segments are clipped `gap` inside the edge; any other silk shape that
    leaves the board is an error, so nothing is dropped silently."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    x0, y0, x1, y1 = outline
    for fp in board.GetFootprints():
        gi = fp.GraphicalItems()          # indexed: iterating it breaks on Python 3.14
        for g in [gi[i].Cast() for i in range(len(gi))]:
            if g.GetLayer() not in (pcbnew.F_SilkS, pcbnew.B_SilkS):
                continue
            # a text's bounding box already includes its stroke
            w = (to(g.GetWidth()) / 2 if isinstance(g, pcbnew.PCB_SHAPE) else 0) + gap
            lo_x, lo_y, hi_x, hi_y = x0 + w, y0 + w, x1 - w, y1 - w
            if not (isinstance(g, pcbnew.PCB_SHAPE) and g.GetShape() == pcbnew.SHAPE_T_SEGMENT):
                b = g.GetBoundingBox()
                if to(b.GetLeft()) < lo_x or to(b.GetTop()) < lo_y or to(b.GetRight()) > hi_x or to(b.GetBottom()) > hi_y:
                    raise ValueError("%s: silkscreen shape leaves the board" % fp.GetReference())
                continue
            ax, ay, bx, by = to(g.GetStart().x), to(g.GetStart().y), to(g.GetEnd().x), to(g.GetEnd().y)
            # Liang-Barsky
            t0, t1, dx, dy = 0.0, 1.0, bx - ax, by - ay
            for p, q in ((-dx, ax - lo_x), (dx, hi_x - ax), (-dy, ay - lo_y), (dy, hi_y - ay)):
                if p == 0:
                    if q < 0:
                        t0, t1 = 1, 0
                elif p < 0:
                    t0 = max(t0, q / p)
                else:
                    t1 = min(t1, q / p)
            if t1 - t0 <= 1e-9 or math.hypot(dx, dy) * (t1 - t0) < 0.2:
                fp.Remove(g)
                continue
            g.SetStart(pcbnew.VECTOR2I(mm(ax + dx * t0), mm(ay + dy * t0)))
            g.SetEnd(pcbnew.VECTOR2I(mm(ax + dx * t1), mm(ay + dy * t1)))


def clip_silk_to_pads(board, gap=0.15):
    """Trim footprint silkscreen segments that come within `gap` of a mask opening on
    their side (edge to pad, the line's width counted): some library
    footprints stop their outline 0.15 mm from a pad at the line's centre,
    which leaves its edge 0.09 mm away (the HRO TYPE-C-31-M-12's shield
    pads). The part of a segment inside a pad's box grown by gap + half the
    width goes; what is left under 0.2 mm long goes too."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    gap += SOLDER_MASK_EXPANSION
    pads = []
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            bb = pad.GetBoundingBox()
            pads.append((to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom()),
                         pad.IsOnLayer(pcbnew.F_Cu), pad.IsOnLayer(pcbnew.B_Cu)))
    for fp in board.GetFootprints():
        gi = fp.GraphicalItems()          # indexed: iterating it breaks on Python 3.14
        for g in [gi[i].Cast() for i in range(len(gi))]:
            if g.GetLayer() not in (pcbnew.F_SilkS, pcbnew.B_SilkS):
                continue
            if not (isinstance(g, pcbnew.PCB_SHAPE) and g.GetShape() == pcbnew.SHAPE_T_SEGMENT):
                continue
            front = g.GetLayer() == pcbnew.F_SilkS
            ax, ay, bx, by = to(g.GetStart().x), to(g.GetStart().y), to(g.GetEnd().x), to(g.GetEnd().y)
            dx, dy = bx - ax, by - ay
            w = to(g.GetWidth()) / 2 + gap + 0.01          # 10 um clear of check_silk's inclusive edge
            keep = [(0.0, 1.0)]
            for x0, y0, x1, y1, on_f, on_b in pads:
                if not (on_f if front else on_b):
                    continue
                # Liang-Barsky: the part of the segment inside the grown pad box
                t0, t1 = 0.0, 1.0
                for p, q in ((-dx, ax - (x0 - w)), (dx, (x1 + w) - ax), (-dy, ay - (y0 - w)), (dy, (y1 + w) - ay)):
                    if p == 0:
                        if q < 0:
                            t0, t1 = 1, 0
                    elif p < 0:
                        t0 = max(t0, q / p)
                    else:
                        t1 = min(t1, q / p)
                if t1 <= t0:
                    continue
                keep = [piece for a0, a1 in keep
                        for piece in ((a0, min(a1, t0)), (max(a0, t1), a1)) if piece[1] > piece[0]]
            if keep == [(0.0, 1.0)]:
                continue
            length = math.hypot(dx, dy)
            keep = [(a0, a1) for a0, a1 in keep if length * (a1 - a0) >= 0.2]
            for k, (a0, a1) in enumerate(keep):
                seg = g if k == 0 else g.Duplicate()
                seg.SetStart(pcbnew.VECTOR2I(mm(ax + dx * a0), mm(ay + dy * a0)))
                seg.SetEnd(pcbnew.VECTOR2I(mm(ax + dx * a1), mm(ay + dy * a1)))
                if k:
                    fp.Add(seg)
            if not keep:
                fp.Remove(g)


SILK_TEXT = (1.0, 0.15)                 # designator height and stroke (JLC minimum stroke)


def name_keepout(board, grow=0.1):
    """A rule area with no vias over the board's name and revision, on every
    copper layer, for the router (the fan-out and the stitching keep off
    every silkscreen word by themselves)."""
    import pcbnew
    mm = pcbnew.FromMM
    dr = board.Drawings()
    for d in [dr[i].Cast() for i in range(len(dr))]:
        if d.Type() != pcbnew.PCB_TEXT_T or " rev " not in d.GetText():
            continue
        x0, y0, x1, y1 = _ink_box(d, grow)
        z = pcbnew.ZONE(board)
        z.SetIsRuleArea(True)
        z.SetZoneName("revision")
        z.SetDoNotAllowVias(True)
        z.SetDoNotAllowTracks(False)
        z.SetDoNotAllowPads(False)
        z.SetDoNotAllowZoneFills(False)
        z.SetDoNotAllowFootprints(False)
        z.SetLayerSet(pcbnew.LSET.AllCuMask())
        ol = z.Outline()
        ol.NewOutline()
        for px, py in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)):
            ol.Append(mm(px), mm(py))
        board.Add(z)


def mark_revision(board, title, revision, at):
    """The board's name and revision, "<title> rev <revision>", on the top
    silkscreen with its bottom-right corner at `at` (mm; normally 1 mm in from
    the body's bottom-right corner), and in its title block (the Gerbers' X2
    file attributes carry it), so boards of different builds can be told
    apart (doc/milestone-1.md, Board revision)."""
    import pcbnew
    mm = pcbnew.FromMM
    t = pcbnew.PCB_TEXT(board)
    t.SetText("%s rev %s" % (title, revision))
    t.SetLayer(pcbnew.F_SilkS)
    t.SetTextSize(pcbnew.VECTOR2I(mm(SILK_TEXT[0]), mm(SILK_TEXT[0])))
    t.SetTextThickness(mm(SILK_TEXT[1]))
    t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_RIGHT)
    t.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_BOTTOM)
    t.SetPosition(pcbnew.VECTOR2I(mm(at[0]), mm(at[1])))
    board.Add(t)
    tb = board.GetTitleBlock()
    tb.SetTitle(title)
    tb.SetRevision(revision)
    tb.SetCompany("Kaplan Labs")
    board.SetTitleBlock(tb)


def _mm_box(bb, grow=0.0):
    import pcbnew
    return (pcbnew.ToMM(bb.GetLeft()) - grow, pcbnew.ToMM(bb.GetTop()) - grow,
            pcbnew.ToMM(bb.GetRight()) + grow, pcbnew.ToMM(bb.GetBottom()) + grow)


def _ink_box(text, grow=0.0):
    """A silkscreen text's box as printed (its strokes), in mm: KiCad's
    bounding box adds line spacing and padding, ~0.5 mm round a 1 mm text."""
    return _mm_box(text.GetEffectiveTextShape().BBox(), grow)


def silk_keepouts(board, surface=None):
    """What a designator must stay off (mm boxes): every pad (grown by JLC's
    0.15 mm silk-to-mask clearance plus the mask expansion), every via (a tented via under a letter is a bump
    in it, and JLC clips silk off an untented one), and each part's
    courtyard and its body (F.Fab outline: a connector's body can reach past
    its courtyard, over the board edge). Returns (pads, vias, {ref:
    courtyard}, {ref: body}); board-only artwork (the logo) has its outline
    as its courtyard."""
    import pcbnew
    if surface not in (None, pcbnew.F_Cu, pcbnew.B_Cu):
        raise ValueError("silk keepout surface must be F.Cu or B.Cu")
    fps = list(board.GetFootprints())
    pads = [_mm_box(p.GetBoundingBox(), 0.15 + SOLDER_MASK_EXPANSION)
            for fp in fps for p in fp.Pads() if surface is None or p.IsOnLayer(surface)]
    tr = board.Tracks()
    vias = [(_mm_box(t.GetBoundingBox()), t.GetNetname()) for t in [tr[i] for i in range(len(tr))]
            if t.Type() == pcbnew.PCB_VIA_T]
    courts, bodies = {}, {}
    for fp in fps:
        side = (pcbnew.B_CrtYd if surface == pcbnew.B_Cu else pcbnew.F_CrtYd) if surface is not None else (pcbnew.B_CrtYd if fp.IsFlipped() else pcbnew.F_CrtYd)
        cy = fp.GetCourtyard(side)
        if cy.OutlineCount():
            courts[fp.GetReference()] = _mm_box(cy.BBox())
        elif surface is None or fp.IsFlipped() == (surface == pcbnew.B_Cu):
            courts[fp.GetReference()] = _mm_box(fp.GetBoundingBox(False))
        gi = fp.GraphicalItems()             # indexed: iterating it breaks on Python 3.14
        # the body: its F.Fab outline, and its own silkscreen marks with it
        back = fp.IsFlipped() if surface is None else surface == pcbnew.B_Cu
        fab = pcbnew.B_Fab if back else pcbnew.F_Fab
        silk = pcbnew.B_SilkS if back else pcbnew.F_SilkS
        boxes = [_mm_box(g.GetBoundingBox()) for g in [gi[i] for i in range(len(gi))]
                 if g.GetLayer() in (fab, silk) and g.Type() == pcbnew.PCB_SHAPE_T]
        if boxes:
            bodies[fp.GetReference()] = union(boxes)
    return pads, vias, courts, bodies


def silk_designators(board, labels=None):
    """[(footprint, text)]: each part's designator on the silkscreen, its own
    reference or, for a part in `labels`, the board text that stands for it."""
    import pcbnew
    labels = labels or {}
    mixed = any(fp.IsFlipped() for fp in board.GetFootprints())
    dr = board.Drawings()
    words = {}
    for d in [dr[i].Cast() for i in range(len(dr))]:
        if d.Type() == pcbnew.PCB_TEXT_T:
            words.setdefault((d.GetText(), d.GetLayer()) if mixed else d.GetText(), d)
    out = []
    for fp in sorted(board.GetFootprints(), key=lambda f: f.GetReference()):
        if fp.GetAttributes() & pcbnew.FP_BOARD_ONLY:
            continue
        label_key = (labels.get(fp.GetReference()), pcbnew.B_SilkS if fp.IsFlipped() else pcbnew.F_SilkS) if mixed else labels.get(fp.GetReference())
        if label_key in words and not fp.Reference().IsVisible():
            out.append((fp, words[label_key]))
        elif fp.Reference().IsVisible():
            out.append((fp, fp.Reference()))
    return out


RESEAT_REACH = 2.0        # mm: how far from its courtyard a designator may move off the vias
RESEAT_REACH_BIG = 0.45   # of its courtyard's size, for a big part (a QFN inside its ring of fan-out vias)


WORD_GAP = 0.5            # mm between two words in one line: closer, "C13" and "C11" read as "C13C11"


def _upright(text):
    return round(text.GetTextAngleDegrees()) % 180 == 90


def run_together(a, a_up, b, b_up, gap=WORD_GAP):
    """Two words (ink boxes, mm) that read as one: the same way round, in
    one line (their boxes share some of the line's height), and closer than
    `gap` along it."""
    if a_up != b_up:
        return False
    if a_up:                                  # reading upwards: the line runs along y
        return a[0] < b[2] and b[0] < a[2] and max(b[1] - a[3], a[1] - b[3]) < gap
    return a[1] < b[3] and b[1] < a[3] and max(b[0] - a[2], a[0] - b[2]) < gap


def place_designators(board, outline, labels=None, gap=0.3, silk_text=None, reseat=False, label_side=None, reach_mm=None):
    """Put every reference designator horizontal, in the first spot around its
    part that clears all pads and vias, every other part's courtyard, every
    part's body, the other designators and board texts, board-only graphics
    (logos) and the board edge. A part in `labels` ({ref: word}) gets that
    word there instead, and its designator is hidden: an LED says what it
    shows, not "D3".

    `reseat`: after routing, move only the designators that a via (the
    fan-out's, the router's) or anything else now sits under, and leave the
    rest where they are. `label_side` ({ref: "N"/"S"/"E"/"W"}) tries that
    side of the part first, so a column of LEDs reads alike. Returns the
    designators moved."""
    import pcbnew
    mm = pcbnew.FromMM
    labels = labels or {}
    label_side = label_side or {}
    mixed = any(fp.IsFlipped() for fp in board.GetFootprints())
    if not reseat:
        for fp in board.GetFootprints():
            if fp.GetReference() in labels and fp.Reference().IsVisible() and \
                    not fp.GetAttributes() & pcbnew.FP_BOARD_ONLY:
                fp.Reference().SetVisible(False)
                t = pcbnew.PCB_TEXT(board)
                t.SetText(labels[fp.GetReference()])
                t.SetLayer(pcbnew.B_SilkS if mixed and fp.IsFlipped() else pcbnew.F_SilkS)
                if mixed and fp.IsFlipped():
                    t.SetMirrored(True)
                board.Add(t)
    items = silk_designators(board, labels)
    pads, vias, courts, bodies = silk_keepouts(board)
    by_surface = {side: silk_keepouts(board, side) for side in (pcbnew.F_Cu, pcbnew.B_Cu)} if mixed else {}
    # a via right at a letter reads as part of it: 0.25 mm clear of the ring
    vias = [(v[0] - 0.15, v[1] - 0.15, v[2] + 0.15, v[3] + 0.15) for v, _ in vias]
    x0, y0, x1, y1 = outline
    inside = (x0 + 0.3, y0 + 0.3, x1 - 0.3, y1 - 0.3)
    dr = board.Drawings()
    # the board's other words (its name and revision): kept clear of too
    # (box, upright) of each word placed
    placed = [(_ink_box(d), _upright(d)) for d in [dr[i].Cast() for i in range(len(dr))]
              if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() == pcbnew.F_SilkS and
              d.GetText() not in labels.values()]

    side_placed = {side: [(_ink_box(d), _upright(d))
                         for d in [dr[i].Cast() for i in range(len(dr))]
                         if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() == silk and
                         d.GetText() not in labels.values()]
                   for side, silk in ((pcbnew.F_Cu, pcbnew.F_SilkS), (pcbnew.B_Cu, pcbnew.B_SilkS))} if mixed else {}
    item_sides = {id(ref): pcbnew.B_Cu if fp.IsFlipped() else pcbnew.F_Cu for fp, ref in items}

    def surface(fp):
        return pcbnew.B_Cu if fp.IsFlipped() else pcbnew.F_Cu

    def words_for(fp):
        return side_placed[surface(fp)] if mixed else placed

    def current_for(fp, excluding=None):
        return [b for k, b in current.items() if k != excluding and
                (not mixed or item_sides[k] == surface(fp))]

    def clear(fp, t, up, others, word_gap=0.1):
        if t[0] < inside[0] or t[1] < inside[1] or t[2] > inside[2] or t[3] > inside[3]:
            return False
        local_pads, _, local_courts, local_bodies = by_surface[surface(fp)] if mixed else (pads, None, courts, bodies)
        near = local_pads + vias + [c for r, c in local_courts.items() if r != fp.GetReference()] + list(local_bodies.values())
        return not any(overlap(t, o, 0.1) for o in near) and \
            not any(overlap(t, o, word_gap) or run_together(t, up, o, o_up) for o, o_up in others)

    if reseat:
        current = {id(ref): (_ink_box(ref), _upright(ref)) for _, ref in items}
    def seat(fp, ref, others):
        """Put `ref` in the first clear spot round its part (see above);
        returns (ink box, upright, text size, size before) or None."""
        spots = []
        # round the courtyard, then (for an imported footprint whose courtyard
        # is only its body, leads outside it) round its pads
        court = courts[fp.GetReference()]
        for cx0, cy0, cx1, cy1 in (court, union([court] + [_mm_box(p.GetBoundingBox(), 0.5) for p in fp.Pads()])):
            mx, my = (cx0 + cx1) / 2, (cy0 + cy1) / 2
            for shift in (0, 1, -1, 2, -2, 3, -3):
                spots += [(mx + shift, cy0 - gap - 0.6), (mx + shift, cy1 + gap + 0.6),
                          (cx0 - gap - 1.5, my + shift), (cx1 + gap + 1.5, my + shift)]
        # then rings a little further out: a 0402's text right above it
        # clips its own pads, which reach nearly to its courtyard; after
        # routing, the vias round a part leave gaps only a little further off
        cx0, cy0, cx1, cy1 = court
        mx, my = (cx0 + cx1) / 2, (cy0 + cy1) / 2
        for out in (1.0, 1.5, 2.0) if reseat else (1.0,):
            for shift in (0, 0.5, -0.5, 1, -1, 1.5, -1.5, 2, -2) if reseat else (0, 1, -1, 2, -2):
                spots += [(mx + shift, cy0 - gap - out), (mx + shift, cy1 + gap + out)]
            if reseat:
                for shift in (0, 0.5, -0.5, 1, -1):
                    spots += [(cx0 - gap - 1.0 - out, my + shift), (cx1 + gap + 1.0 + out, my + shift)]
        size = pcbnew.ToMM(ref.GetTextSize().y)
        spots = [(sx, sy, 0, size) for sx, sy in spots]
        # then the nearest clear spot on a 0.2 mm grid, up to RESEAT_REACH
        # from the courtyard, horizontal and then (a crowd of vias or small
        # parts leaves only narrow gaps) turned to read upwards; then the
        # same at JLC's 0.8 mm minimum text height
        ref.SetTextAngleDegrees(0)
        box0 = _ink_box(ref)
        w0, h0 = [b - a for a, b in zip(box0[:2], box0[2:])]
        side = label_side.get(fp.GetReference())
        if side:
            spots.insert(0, ({"E": cx1 + gap + w0 / 2, "W": cx0 - gap - w0 / 2}.get(side, mx),
                             {"N": cy0 - gap - h0 / 2, "S": cy1 + gap + h0 / 2}.get(side, my), 0, size))
        for angle, tsize in ((0, size), (90, size), (0, 0.8), (90, 0.8)):
            if tsize > size:
                continue
            w, h = w0 * tsize / size, h0 * tsize / size
            tw, th = (w, h) if angle == 0 else (h, w)
            grid = []
            reach = max(RESEAT_REACH, RESEAT_REACH_BIG * max(cx1 - cx0, cy1 - cy0))
            if reach_mm is not None:
                if not math.isfinite(reach_mm) or reach_mm <= 0:raise ValueError("designator reach must be finite and positive")
                reach = max(reach, reach_mm)
            steps = int((reach + max(w, h)) / 0.2)
            for i in range(-steps, steps + 1):
                for j in range(-steps, steps + 1):
                    sx, sy = mx + 0.2 * i, my + 0.2 * j
                    # how far the text's box is from the courtyard's
                    dx = max(cx0 - (sx + tw / 2), (sx - tw / 2) - cx1, 0)
                    dy = max(cy0 - (sy + th / 2), (sy - th / 2) - cy1, 0)
                    if 0 < max(dx, dy) and math.hypot(dx, dy) <= reach:
                        grid.append((math.hypot(dx, dy), sx, sy))
            spots += [(sx, sy, angle, tsize) for _, sx, sy in sorted(grid)]
        stroke = pcbnew.ToMM(ref.GetTextThickness())
        # words 0.5 mm apart where there is room; 0.1 mm where there isn't
        # (but never closer than WORD_GAP in one line: run_together)
        for sx, sy, angle, tsize, word_gap in [q + (0.5,) for q in spots] + [q + (0.1,) for q in spots]:
            ref.SetTextSize(pcbnew.VECTOR2I(mm(tsize), mm(tsize)))
            ref.SetTextThickness(mm(min(stroke, max(0.15, tsize * 0.15))))
            ref.SetTextAngleDegrees(angle)
            ref.SetPosition(pcbnew.VECTOR2I(mm(sx), mm(sy)))
            t = _ink_box(ref)
            if clear(fp, t, bool(angle), others, word_gap):
                return t, bool(angle), tsize, size
        return None

    def note(fp, got):
        t, up, tsize, size = got
        return fp.GetReference() + (" (turned)" if up else "") + (" (%.1f mm)" % tsize if tsize != size else "")

    def state(ref):
        return (ref.GetPosition(), ref.GetTextAngleDegrees(), ref.GetTextSize(), ref.GetTextThickness())

    def restore(ref, st):
        ref.SetPosition(st[0])
        ref.SetTextAngleDegrees(st[1])
        ref.SetTextSize(st[2])
        ref.SetTextThickness(st[3])

    moved = []
    for fp, ref in items:
        if reseat:
            others = words_for(fp) + current_for(fp, id(ref))
            if clear(fp, *current[id(ref)], others):
                continue
        else:
            others = words_for(fp)
            size, stroke = silk_text or SILK_TEXT   # a board of 0402s may ask for JLC's 0.8 mm minimum
            ref.SetTextSize(pcbnew.VECTOR2I(mm(size), mm(size)))
            ref.SetTextThickness(mm(stroke))
            ref.SetTextAngleDegrees(0)
            ref.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_CENTER)
            ref.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)
        got = seat(fp, ref, others)
        if got and not reseat:
            words_for(fp).append(got[:2])
            continue
        if got:
            current[id(ref)] = got[:2]
            moved.append(note(fp, got))
            continue
        if reseat:
            # walled in: the neighbours' designators within reach step aside.
            # Each is taken off in turn, nearest first; this one is seated,
            # then the neighbour again. If the neighbour then finds no spot,
            # both go back as they were and the next neighbour is tried
            current.pop(id(ref), None)            # its old spot is no obstacle to itself
            court = courts[fp.GetReference()]
            cx, cy = (court[0] + court[2]) / 2, (court[1] + court[3]) / 2
            others_items = [(q, r) for q, r in items if id(r) in current and r is not ref and
                            (not mixed or surface(q) == surface(fp))]
            others_items.sort(key=lambda qr: math.hypot((current[id(qr[1])][0][0] + current[id(qr[1])][0][2]) / 2 - cx,
                                                        (current[id(qr[1])][0][1] + current[id(qr[1])][0][3]) / 2 - cy))
            ok = None
            for q, r in others_items[:6]:
                saved_r, saved_box = state(r), current.pop(id(r))
                got = seat(fp, ref, words_for(fp) + current_for(fp))
                if got:
                    current[id(ref)] = got[:2]
                    got_r = seat(q, r, words_for(q) + current_for(q, id(r)))
                    if got_r:
                        current[id(r)] = got_r[:2]
                        ok = (got, q, got_r)
                        break
                    current.pop(id(ref))
                restore(r, saved_r)
                current[id(r)] = saved_box
            if ok:
                moved += [note(fp, ok[0]), note(ok[1], ok[2]) + " (to make room)"]
                continue
        if reseat and isinstance(ref, pcbnew.PCB_FIELD):
            # walled in by its own fan-out (a QFN's ring of vias, a cap
            # between them): left off the silkscreen rather than printed
            # over vias. The CPL places it; the build output lists it
            ref.SetVisible(False)
            current.pop(id(ref), None)
            moved.append(fp.GetReference() + " (left off: no clear spot)")
            continue
        raise ValueError("%s: no room for its %s%s; move parts apart" % (
            fp.GetReference(), "designator" if isinstance(ref, pcbnew.PCB_FIELD) else "label %r" % ref.GetText(),
            " clear of the vias" if reseat else ""))
    if reseat:
        # the board's name and revision: a finger tab's GND ties or the
        # presence link can put vias in its corner; it slides up and left
        # from there to the nearest clear spot, still right-aligned
        near = pads + vias + list(courts.values()) + list(bodies.values()) + [b for b, _ in current.values()]
        for d in [dr[i].Cast() for i in range(len(dr))]:
            if d.Type() != pcbnew.PCB_TEXT_T or " rev " not in d.GetText():
                continue
            if mixed:
                if d.GetLayer() not in (pcbnew.F_SilkS, pcbnew.B_SilkS):
                    continue
                side = pcbnew.B_Cu if d.GetLayer() == pcbnew.B_SilkS else pcbnew.F_Cu
                local_pads, _, local_courts, local_bodies = by_surface[side]
                near = local_pads + vias + list(local_courts.values()) + list(local_bodies.values()) + [b for k, (b, _) in current.items() if item_sides[k] == side]
            if not any(overlap(_ink_box(d), o, 0.1) for o in near):
                continue
            x, y = pcbnew.ToMM(d.GetPosition().x), pcbnew.ToMM(d.GetPosition().y)
            for dx, dy in sorted(((0.5 * i, 0.25 * j) for i in range(61) for j in range(65)),
                                 key=lambda s: s[0] + 2 * s[1]):
                d.SetPosition(pcbnew.VECTOR2I(mm(x - dx), mm(y - dy)))
                t = _ink_box(d)
                if t[0] >= inside[0] and t[1] >= inside[1] and t[2] <= inside[2] and t[3] <= inside[3] and \
                        not any(overlap(t, o, 0.1) for o in near):
                    moved.append(repr(d.GetText()))
                    break
            else:
                raise ValueError("%r: no clear spot for the board's name near its corner" % d.GetText())
    return moved


def check_designators(board, labels=None):
    """Designators (and the LED words standing for them) that sit over a via,
    over another part's courtyard, over any part's body (its own included:
    a connector overhanging its courtyard), or over another word on the
    silkscreen. Returns problems."""
    import pcbnew
    items = silk_designators(board, labels)
    mixed = any(fp.IsFlipped() for fp in board.GetFootprints())
    by_surface = {side: silk_keepouts(board, side) for side in (pcbnew.F_Cu, pcbnew.B_Cu)} if mixed else {}
    text_sides = {fp.GetReference(): t.GetLayer() for fp, t in items}
    _, vias, courts, bodies = silk_keepouts(board)
    dr = board.Drawings()
    words = [(d.GetText(), _ink_box(d)) for d in [dr[i].Cast() for i in range(len(dr))]
             if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() == pcbnew.F_SilkS]
    side_words = {side: [(d.GetText(), _ink_box(d)) for d in [dr[i].Cast() for i in range(len(dr))]
                         if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() == side]
                  for side in (pcbnew.F_SilkS, pcbnew.B_SilkS)} if mixed else {}
    bad = []
    boxes = [(fp.GetReference(), t.GetText(), _ink_box(t), _upright(t)) for fp, t in items]
    for i, (ref, text, t, up) in enumerate(boxes):
        if mixed:
            silk = text_sides[ref]
            _, vias, courts, bodies = by_surface[pcbnew.B_Cu if silk == pcbnew.B_SilkS else pcbnew.F_Cu]
            words = side_words[silk]
        what = "designator %s" % ref if text == ref else "label %r (%s)" % (text, ref)
        for v, net in vias:
            if overlap(t, v):
                bad.append("%s over a via of %s" % (what, net))
        for r, c in courts.items():
            if r != ref and overlap(t, c):
                bad.append("%s over the courtyard of %s" % (what, r))
        for r, b in bodies.items():
            if overlap(t, b):
                bad.append("%s over the body of %s" % (what, r))
        for r, other, o, o_up in boxes:
            if r != ref and (not mixed or text_sides[r] == text_sides[ref]) and overlap(t, o):
                bad.append("%s over the designator of %s" % (what, r))
        for r, other, o, o_up in boxes[i + 1:]:
            if (not mixed or text_sides[r] == text_sides[ref]) and not overlap(t, o) and run_together(t, up, o, o_up):
                bad.append("%s runs into %r: under %.1f mm apart in one line" % (what, other, WORD_GAP))
        for word, o in words:
            if word != text and " rev " in word and overlap(t, o):
                bad.append("%s over %r" % (what, word))
    if mixed:
        words = side_words[pcbnew.F_SilkS] + side_words[pcbnew.B_SilkS]
    for word, o in words:                        # the board's name and revision
        if " rev " in word:
            bad += ["%r over a via of %s" % (word, net) for v, net in vias if overlap(o, v)]
    return bad


def check_silk(board, clearance=0.15, artwork=False, labels=None):          # JLC: silkscreen 0.15 mm from mask openings
    """Silkscreen lines and texts that touch a pad (KiCad's DRC does not check
    a footprint's silkscreen against its own pads), designators out of place
    (check_designators), and with `artwork`, tracks and vias under a
    board-only graphic (the logo). Returns problems."""
    import pcbnew
    mm = pcbnew.FromMM
    clearance += SOLDER_MASK_EXPANSION
    pads = []
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            bb = pad.GetBoundingBox()
            bb.Inflate(mm(clearance))
            pads.append((fp.GetReference(), pad.GetNumber(), pad.IsOnLayer(pcbnew.F_Cu),
                         pad.IsOnLayer(pcbnew.B_Cu), bb, pad))
    bad = []
    for fp in board.GetFootprints():
        gi = fp.GraphicalItems()          # indexed: iterating it breaks on Python 3.14
        graphics = [gi[i].Cast() for i in range(len(gi))]
        items = [(g, g.GetLayer()) for g in graphics if g.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS)]
        items += [(t, t.GetLayer()) for t in (fp.Reference(), fp.Value())
                  if t.IsVisible() and t.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS)]
        for g, layer in items:
            front = layer == pcbnew.F_SilkS
            if isinstance(g, pcbnew.PCB_SHAPE) and g.GetShape() == pcbnew.SHAPE_T_SEGMENT:
                a, b = g.GetStart(), g.GetEnd()
                steps = max(2, int(pcbnew.ToMM((b - a).EuclideanNorm()) / 0.02))
                probes = [pcbnew.VECTOR2I(int(a.x + (b.x - a.x) * k / steps), int(a.y + (b.y - a.y) * k / steps))
                          for k in range(steps + 1)]
                # the line's edge, not its centre: the pad box grows by half its width
                half = g.GetWidth() // 2
                hit = lambda bb, pad, half=half: any(                          # noqa: E731
                    pcbnew.BOX2I(bb.GetPosition() - pcbnew.VECTOR2I(half, half),
                                 bb.GetSize() + pcbnew.VECTOR2L(2 * half, 2 * half)).Contains(pt) for pt in probes)
            elif isinstance(g, pcbnew.PCB_SHAPE) and g.GetShape() == pcbnew.SHAPE_T_CIRCLE:
                # the ring, not its bounding box (which holds the pad it rings)
                c, r = g.GetCenter(), g.GetRadius() + g.GetWidth() / 2
                probes = [pcbnew.VECTOR2I(int(c.x + r * math.cos(k * math.pi / 90)),
                                          int(c.y + r * math.sin(k * math.pi / 90))) for k in range(180)]
                probes += [pcbnew.VECTOR2I(int(c.x + (r - g.GetWidth()) * math.cos(k * math.pi / 90)),
                                           int(c.y + (r - g.GetWidth()) * math.sin(k * math.pi / 90)))
                           for k in range(180)]
                hit = lambda bb, pad, probes=probes: any(                        # noqa: E731
                    bb.Contains(pt) and pad.HitTest(pt, mm(clearance)) for pt in probes)
            else:
                # a text by its strokes: its bounding box pads it by ~0.25 mm a side
                gb = g.GetEffectiveTextShape().BBox() if isinstance(g, pcbnew.EDA_TEXT) else g.GetBoundingBox()
                hit = lambda bb, pad, gb=gb: bb.Intersects(gb)           # noqa: E731
            # Most footprint artwork is nowhere near most pads. Reject by a
            # cheap bounding box before probing every point on each stroke.
            art_box = gb if isinstance(g, pcbnew.EDA_TEXT) else g.GetBoundingBox()
            for ref, num, on_f, on_b, bb, pad in pads:
                if (on_f if front else on_b) and art_box.Intersects(bb) and hit(bb, pad):
                    bad.append("silkscreen of %s touches pad %s of %s" % (fp.GetReference(), num, ref))
    # the board's own silkscreen words (labels, the revision) against every
    # pad, and the free-standing ones (not a part's label) against every
    # part's courtyard on their side
    courts = []
    for fp in board.GetFootprints():
        side = pcbnew.F_CrtYd if fp.GetLayer() == pcbnew.F_Cu else pcbnew.B_CrtYd
        if len(fp.Pads()):
            cb = fp.GetCourtyard(side).BBox() if fp.GetCourtyard(side).OutlineCount() else None
            if cb is not None:
                courts.append((fp.GetReference(), fp.GetLayer() == pcbnew.F_Cu, cb))
    dr = board.Drawings()                        # indexed: iterating it breaks on Python 3.14
    for d in [dr[i].Cast() for i in range(len(dr))]:
        if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS):
            front = d.GetLayer() == pcbnew.F_SilkS
            gb = d.GetEffectiveTextShape().BBox()
            for ref, num, on_f, on_b, bb, _ in pads:
                if (on_f if front else on_b) and bb.Intersects(gb):
                    bad.append("label %r touches pad %s of %s" % (d.GetText(), num, ref))
            if " rev " in d.GetText():
                for ref, on_f, cb in courts:
                    if on_f == front and cb.Intersects(gb):
                        bad.append("label %r overlaps the courtyard of %s" % (d.GetText(), ref))
    bad += check_designators(board, labels)
    if artwork:
        # no track or via on the copper under the artwork (the logo): it
        # would show through the mask as a ridge across it (silk_keepout)
        tr = board.Tracks()
        tracks = [tr[i].Cast() for i in range(len(tr))]
        for fp in board.GetFootprints():
            if not str(fp.GetFPID().GetLibItemName()).startswith(LOGO):
                continue
            layer = pcbnew.B_Cu if fp.IsFlipped() else pcbnew.F_Cu
            fb = fp.GetBoundingBox(False)
            for t in tracks:
                if not t.IsOnLayer(layer) or not t.GetBoundingBox().Intersects(fb):
                    continue
                # the track itself, not its bounding box (a diagonal past a corner)
                a, b = t.GetStart(), t.GetEnd()
                half = t.GetWidth() // 2
                grown = pcbnew.BOX2I(fb.GetPosition() - pcbnew.VECTOR2I(half, half),
                                     fb.GetSize() + pcbnew.VECTOR2L(2 * half, 2 * half))
                steps = max(1, int(pcbnew.ToMM((b - a).EuclideanNorm()) / 0.05))
                if any(grown.Contains(pcbnew.VECTOR2I(int(a.x + (b.x - a.x) * k / steps),
                                                      int(a.y + (b.y - a.y) * k / steps)))
                       for k in range(steps + 1)):
                    bad.append("a %s of %s runs under the artwork %s" % (
                        "via" if t.Type() == pcbnew.PCB_VIA_T else "track", t.GetNetname(), fp.GetFPID().GetLibItemName()))
    return sorted(set(bad))


def wrl_box(path, offset, rotation):
    """XY box (footprint coordinates, Y down) of a VRML model's parts at or
    above the board surface, placed with KiCad's offset and Z rotation."""
    xs, ys = [], []
    for block in re.findall(r'point\s*\[([^\]]*)\]', open(path).read()):
        n = [float(v) * 2.54 for v in re.findall(r'-?[\d.]+(?:e-?\d+)?', block)]   # VRML unit: 0.1"
        for x, y, z in zip(n[0::3], n[1::3], n[2::3]):
            if z < 0:
                continue                             # legs through the board
            a = math.radians(rotation[2])
            x, y = x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a)
            xs.append(x + offset[0])
            ys.append(-(y + offset[1]))              # model Y is up, the footprint's down
    return min(xs), min(ys), max(xs), max(ys)


def check_models(tolerance=0.6):
    """Every MODEL_OVERRIDES model sits on its footprint's F.Fab outline: the
    box centres agree within `tolerance` and so do the widths."""
    import pcbnew
    bad = []
    for fpid, entry in MODEL_OVERRIDES.items():
        model, offset, rotation = entry[:3]
        lib, name = fpid.split(":")
        fp = pcbnew.FootprintLoad(footprint_dir(lib), name)
        gi = fp.GraphicalItems()
        fab = [gi[i].Cast().GetBoundingBox() for i in range(len(gi)) if gi[i].GetLayer() == pcbnew.F_Fab
               and gi[i].Cast().GetClass() == "PCB_SHAPE"]
        f = (min(pcbnew.ToMM(b.GetLeft()) for b in fab), min(pcbnew.ToMM(b.GetTop()) for b in fab),
             max(pcbnew.ToMM(b.GetRight()) for b in fab), max(pcbnew.ToMM(b.GetBottom()) for b in fab))
        m = wrl_box(os.path.join(HW_LIB, "models", model), offset, rotation)
        dc = math.hypot((m[0] + m[2] - f[0] - f[2]) / 2, (m[1] + m[3] - f[1] - f[3]) / 2)
        dw = abs((m[2] - m[0]) - (f[2] - f[0]) - (entry[3] if len(entry) > 3 else 0))
        if dc > tolerance or dw > tolerance:
            bad.append("%s: model %s is %.2f mm off the fab outline (width differs %.2f mm)"
                       % (fpid, model, dc, dw))
    return bad


def canonical_dsn(text, seed=0):
    """The Specctra DSN in an order of our own: KiCad's export lists parts,
    images and net pins in an order that changes from run to run, and
    Freerouting's result depends on it. Everything order-free is sorted;
    `seed` > 0 then shuffles those lists by a seeded generator, so a retry
    gets a different, but still reproducible, problem."""
    import random
    rnd = random.Random(seed)
    text = text.replace('(string_quote ")', "(string_quote QUOTE_CHAR)")
    tree = parse(text)

    def order(items, key):
        items.sort(key=key)
        if seed:
            rnd.shuffle(items)
        return items

    def reorder(node, tag, key):
        """sort (and maybe shuffle) node's `tag` children in place, keeping
        everything else where it was"""
        slots = [i for i, e in enumerate(node) if isinstance(e, list) and e and e[0] == tag]
        for i, e in zip(slots, order([node[i] for i in slots], key)):
            node[i] = e
    name = lambda e: str(e[1])                                     # noqa: E731
    # KiCad names a footprint's variants base, base::1, base::2 in the order
    # it meets them: name them by content instead
    rename = {}
    for library in find(tree, "library"):
        groups = {}
        for img in find(library, "image"):
            groups.setdefault(str(img[1]).split("::")[0], []).append(img)
        for base, imgs in groups.items():
            imgs.sort(key=lambda img: dump(img[2:]))
            for n, img in enumerate(imgs):
                new = base if n == 0 else "%s::%d" % (base, n)
                rename[str(img[1])] = new
                img[1] = type(img[1])(new)
    for placement in find(tree, "placement"):
        for comp in find(placement, "component"):
            comp[1] = type(comp[1])(rename.get(str(comp[1]), str(comp[1])))
    for placement in find(tree, "placement"):
        reorder(placement, "component", name)
        for comp in find(placement, "component"):
            reorder(comp, "place", name)
    for wiring in find(tree, "wiring"):                # pre-routed copper
        # KiCad sometimes joins connected segments into one path: split every
        # path into its segments
        out = []
        for e in wiring:
            path = find1(e, "path") if isinstance(e, list) and e and e[0] == "wire" else None
            if path is None or len(path) <= 7:
                out.append(e)
                continue
            pts = path[3:]
            for i in range(0, len(pts) - 2, 2):
                out.append([p if p is not path else path[:3] + pts[i:i + 4] for p in e])
        wiring[:] = out
        reorder(wiring, "wire", dump)
        reorder(wiring, "via", dump)
    for library in find(tree, "library"):
        reorder(library, "image", name)
        reorder(library, "padstack", name)
    for network in find(tree, "network"):
        reorder(network, "net", name)
        for net in find(network, "net"):
            for pins in find(net, "pins"):
                pins[1:] = order(pins[1:], str)
        for cls in find(network, "class"):
            cls[2:] = [e for e in cls[2:] if isinstance(e, list)] + order(
                [e for e in cls[2:] if not isinstance(e, list)], str)
    return dump(tree).replace("(string_quote QUOTE_CHAR)", '(string_quote ")')


def remove_dangling(board, pours=(), trim=False, keep_vias=()):
    """What Freerouting sometimes leaves behind: a via joined on one layer
    only, or a track whose end meets nothing. Removed until none is left, as
    KiCad's own cleanup does. Nets in `pours` are left alone: their pours
    are not filled yet, so their vias would look dangling. `trim`: a track
    with a free end that other copper of its net meets along its body (a
    tap on it) carries that copper's connection, so it is shortened to the
    farthest such tap instead of removed. `keep_vias`: boxes (x0, y0, x1, y1, nm) in which no via is
    removed (a via there is joined by a pour that is not filled yet). Returns the count of removed
    items (trimmed ones are not counted).
    Every copper layer counts (inner signal layers too). The geometry is read
    once into plain numbers: on a board with thousands of tracks, the SWIG
    proxies of Cast() items stop working part-way through (Python 3.14)."""
    import pcbnew
    copper = [l for l in board.GetEnabledLayers().CuStack()]
    pads = {}
    for fp in board.GetFootprints():
        for p in fp.Pads():
            pads.setdefault(p.GetNetname(), []).append(p)
    tracks = board.Tracks()                      # indexed: iterating it breaks on Python 3.14
    segs, vias = {}, {}
    for i in range(len(tracks)):
        t = tracks[i]
        net = t.GetNetname()
        if net in pours:
            continue
        a, b = t.GetStart(), t.GetEnd()
        if t.Type() == pcbnew.PCB_VIA_T:
            vias.setdefault(net, []).append((i, a.x, a.y, t.Cast().GetWidth(pcbnew.F_Cu) // 2))
        elif t.Type() == pcbnew.PCB_TRACE_T:
            segs.setdefault(net, []).append((i, a.x, a.y, b.x, b.y, t.GetWidth() // 2, t.GetLayer()))

    def seg_dist(x, y, ax, ay, bx, by):
        dx, dy = bx - ax, by - ay
        k = 0.0 if dx == dy == 0 else max(0.0, min(1.0, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy)))
        return math.hypot(x - ax - k * dx, y - ay - k * dy)

    gone = set()
    trimmed = {}                                 # index -> (ax, ay, bx, by): the shortened track

    def taps(i, net):
        """Positions t in [0, 1] along track i where other copper of its net (a pad, a via, another
        track's end) meets its body, that copper not being removed."""
        _, ax, ay, bx, by, w, layer = next(r for r in segs[net] if r[0] == i)
        dx, dy = bx - ax, by - ay
        sq = dx * dx + dy * dy
        if not sq:
            return []
        found = []

        def at(x, y, reach):
            k = max(0.0, min(1.0, ((x - ax) * dx + (y - ay) * dy) / sq))
            if math.hypot(x - ax - k * dx, y - ay - k * dy) <= w + reach:
                found.append(k)
        for p in pads.get(net, ()):
            if p.IsOnLayer(layer):
                bb = p.GetBoundingBox()
                at(bb.GetCenter().x, bb.GetCenter().y, max(bb.GetWidth(), bb.GetHeight()) // 2)
        for j, vx, vy, r in vias.get(net, ()):
            if j not in gone:
                at(vx, vy, r)
        for j, cx, cy, ex, ey, w2, l in segs[net]:
            if j != i and j not in gone and l == layer:
                at(cx, cy, w2)
                at(ex, ey, w2)
        return found

    def joined(x, y, layer, net, reach, skip):
        """anything of `net` on `layer` at (x, y): a pad, a via, another track"""
        pt = pcbnew.VECTOR2I(int(x), int(y))
        for p in pads.get(net, ()):
            if p.IsOnLayer(layer) and p.HitTest(pt, int(reach)):
                return True
        for i, vx, vy, r in vias.get(net, ()):
            if i != skip and i not in gone and math.hypot(x - vx, y - vy) <= r + reach:
                return True
        for i, ax, ay, bx, by, w, l in segs.get(net, ()):
            if i != skip and i not in gone and l == layer and seg_dist(x, y, ax, ay, bx, by) <= w + reach:
                return True
        return False
    # to a fixed point on the numbers, then remove everything at once: after
    # a Remove, the board's SWIG proxies can no longer be listed again
    while True:
        more = set()
        for net, vs in vias.items():
            for i, x, y, r in vs:
                if i not in gone and sum(1 for l in copper if joined(x, y, l, net, r, i)) < 2 and \
                        not any(b[0] <= x <= b[2] and b[1] <= y <= b[3] for b in keep_vias):
                    more.add(i)
        cut = {}
        for net, ss in segs.items():
            for i, ax, ay, bx, by, w, l in ss:
                if i not in gone and not (joined(ax, ay, l, net, w, i) and joined(bx, by, l, net, w, i)):
                    ks = taps(i, net) if trim and i not in trimmed else []
                    if ks and max(ks) > min(ks):
                        # keep the part between the taps; an end that is joined keeps its place
                        t0 = 0.0 if joined(ax, ay, l, net, w, i) else min(ks)
                        t1 = 1.0 if joined(bx, by, l, net, w, i) else max(ks)
                        if t1 > t0:
                            cut[i] = (net, (ax + (bx - ax) * t0, ay + (by - ay) * t0,
                                            ax + (bx - ax) * t1, ay + (by - ay) * t1))
                            continue
                    more.add(i)
        if not more and not cut:
            break
        for i, (net, ends) in cut.items():
            trimmed[i] = tuple(int(round(v)) for v in ends)
            segs[net] = [(j, *trimmed[i], w, l) if j == i else (j, ax, ay, bx, by, w, l)
                         for j, ax, ay, bx, by, w, l in segs[net]]
        gone |= more
    # removed from the end, by index, each proxy dropped at once: holding
    # proxies of removed items breaks SWIG for the rest of the process
    for i, (ax, ay, bx, by) in trimmed.items():
        if i not in gone:
            tracks[i].SetStart(pcbnew.VECTOR2I(ax, ay))
            tracks[i].SetEnd(pcbnew.VECTOR2I(bx, by))
    for i in sorted(gone, reverse=True):
        board.Delete(tracks[i])
    return len(gone)


def freerouting_left(log, pours=()):
    """The connections a Freerouting run left, from its log: the nets it
    lists (less the `pours`), and a marker when its final count is more than
    it listed (it does not always list them)."""
    listed = re.findall(r"Net '([^']+)' \((\d+) unrouted", log)
    left = sorted({n for n, _ in listed if n not in pours})
    final = re.findall(r"Auto-routing stage completed:.*?final score: [\d.]+ \((\d+) unrouted", log)
    if final and int(final[-1]) > sum(int(k) for _, k in listed):
        left.append("%d more, not listed" % (int(final[-1]) - sum(int(k) for _, k in listed)))
    return left


def freerouting_violations(log):
    """The clearance violations Freerouting's run ended with, from its log."""
    final = re.findall(r"Auto-routing stage completed:.*?final score: [\d.]+ \(\d+ unrouted and (\d+) violation", log)
    return int(final[-1]) if final else None


def fixed_violations(dsn, env):
    """The violations a DSN starts with, before any routing (the fixed
    items: pads, pre-routed tracks and vias), from Freerouting's own DRC."""
    import json
    report = dsn + ".drc.json"
    subprocess.run(["freerouting", "-de", dsn, "-drc", report, "--gui.enabled=false",
                    _freerouting_state_arg(dsn)], capture_output=True, env=env)
    try:
        return sum(1 for v in json.load(open(report))["violations"] if "learance" in v["type"])
    except (OSError, ValueError, KeyError):
        return None


def _freerouting_state_arg(dsn):
    """Keep router state writable and local to this build, including in a sandbox."""
    state = os.path.join(os.path.dirname(os.path.abspath(dsn)), "freerouting-state")
    return "--user_data_path=" + state


def _freerouting_cmd(dsn, ses, max_passes, fanout=True):
    """Freerouting's command line. One optimiser thread (-mt 1): with a pool
    the route, and whether it completes, changes from run to run. fanout=False
    drops its fan-out stage (--router.fanout.enabled=false, Freerouting 2.4.1):
    a board that pre-places its own fan-out vias (main.py) gains nothing from
    it, and on the seeded main board it took 6.5-11 minutes a pass without the
    unrouted count ever falling."""
    return ["freerouting", "-de", dsn, "-do", ses, "-mp", str(max_passes), "-mt", "1", "--gui.enabled=false",
            _freerouting_state_arg(dsn)] + \
           ([] if fanout else ["--router.fanout.enabled=false"])


def _route_parallel(board, workdir, passes, pours, tries, salt, parallel, env, timeout=None, fanout=True):
    """`parallel` Freerouting runs at once, each on its own ordering (salt) of
    the problem and its own copy of the DSN, for each of `tries` pass
    budgets. The run kept is the lowest-salted one that routes completely
    and adds no violation to those the fixed items start with (one that does
    has copper too close, which KiCad's DRC then throws out with the whole
    round): once run k qualifies, the runs after it are stopped and the ones
    before it waited for, so the result depends on the salts, never on timing.
    `timeout` (seconds) is each run's wall-time cap: a run still going then
    is stopped and counts as left, with the unrouted count its log last
    showed. Returns (session file, its salt), or raises with what was left."""
    import pcbnew
    import time
    pdir = os.path.join(workdir, "route-parallel")
    os.makedirs(pdir, exist_ok=True)
    left_all = {}
    for attempt in range(tries):
        jobs = []
        fixed = None
        for k in range(parallel):
            sk = salt + attempt * parallel + k
            stable_uuids(board, sk)
            dsn = os.path.join(pdir, "route-%d.dsn" % sk)
            ses = os.path.join(pdir, "route-%d.ses" % sk)
            log = os.path.join(pdir, "route-%d.log" % sk)
            if not pcbnew.ExportSpecctraDSN(board, dsn):
                raise RuntimeError("DSN export failed")
            with open(dsn) as f:
                text = canonical_dsn(f.read(), sk)
            with open(dsn, "w") as f:
                f.write(text)
            if os.path.exists(ses):
                os.remove(ses)
            if fixed is None:                    # the same fixed items in every ordering
                fixed = fixed_violations(dsn, env)
            logf = open(log, "w")
            proc = subprocess.Popen(_freerouting_cmd(dsn, ses, passes * (attempt + 1), fanout),
                                    stdout=logf, stderr=subprocess.STDOUT,
                                    env=env, start_new_session=True)   # its own group: the java under the script
            jobs.append([sk, proc, ses, log, logf, None, time.time()])
        chosen = None
        while chosen is None:
            for job in jobs:
                sk, proc, ses, log, logf, done, t0 = job
                if done is None and timeout and proc.poll() is None and time.time() - t0 > timeout:
                    import signal
                    try:
                        os.killpg(proc.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    proc.wait()
                    logf.close()
                    last = re.findall(r"\((\d+) unrouted and (\d+) violation", open(log).read())
                    job[5] = "left"
                    left_all[sk] = ["timeout after %d s (last: %s unrouted, %s violations)"
                                    % (timeout, *(last[-1] if last else ("?", "?")))]
                    continue
                if done is None and proc.poll() is not None:
                    logf.close()
                    text = open(log).read()
                    left = freerouting_left(text, pours)
                    extra = (freerouting_violations(text) or 0) - fixed if fixed is not None else 0
                    if not left and extra > 0:
                        left = ["%d violations more than the fixed items' %d" % (extra, fixed)]
                    job[5] = "ok" if (proc.returncode == 0 and not left and os.path.exists(ses)) else "left"
                    left_all[sk] = left or ["exit %d" % proc.returncode]
            # the first job, in salt order, that is not a failure decides
            for job in jobs:
                if job[5] == "left":
                    continue
                if job[5] == "ok":
                    chosen = job
                break
            else:
                break                                    # every job failed: more passes
            if chosen is None:
                time.sleep(5)
        for job in jobs:
            if job[5] is None:
                import signal
                try:
                    os.killpg(job[1].pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                job[1].wait()
                job[4].close()
        if chosen:
            with open(os.path.join(workdir, "freerouting.log"), "w") as f:
                f.write(open(chosen[3]).read())
            return chosen[2], chosen[0]
    raise RuntimeError("Freerouting left %s unrouted after %d rounds of %d parallel runs (see %s)"
                       % (sorted({n for v in left_all.values() for n in v})[:8], tries, parallel, pdir))


def _replay_session(board, workdir, manifest, preroute_board):
    """Recreate one salted DSN, capture the matching SES, and import neither yet."""
    import pcbnew
    import sesreplay
    if not preroute_board:
        raise ValueError('SES replay requires the generated pre-route board path')
    chosen = manifest['salt']
    stable_uuids(board, chosen)
    directory = os.path.join(workdir, 'route-parallel')
    os.makedirs(directory, exist_ok=True)
    dsn = os.path.join(directory, 'route-%d.dsn' % chosen)
    if not pcbnew.ExportSpecctraDSN(board, dsn):
        raise RuntimeError('replay DSN export failed')
    with open(dsn) as source:
        canonical = canonical_dsn(source.read(), chosen)
    with open(dsn, 'w') as target:
        target.write(canonical)
    return sesreplay.capture(manifest, workdir, preroute_board, dsn)


def autoroute(board, workdir, passes=40, pours=(), tries=3, salt=0, parallel=0, timeout=None, heap=None,
              replay=None, preroute_board=None, fanout=True):
    """Route with Freerouting through a Specctra DSN/SES round trip. Its run
    sometimes stops with connections left; those outside the `pours` nets
    (which the pours and stitching join) mean another try with more passes,
    and an error after `tries`. `salt` starts the tries' orderings further
    on, for a second round that must not repeat the first. With `parallel`
    > 0 each try runs that many differently ordered routes at once
    (_route_parallel), each capped at `timeout` seconds of wall time. `fanout`
    False turns Freerouting's own fan-out stage off (_freerouting_cmd). `heap`
    (e.g. "1g") caps each Freerouting JVM's heap: by default Java takes a
    quarter of the RAM, which is what limited how many ran at once (a run's
    live data is ~110 MB)."""
    import pcbnew
    dsn = os.path.join(workdir, "route.dsn")
    ses = os.path.join(workdir, "route.ses")
    env = dict(os.environ, JAVA_TOOL_OPTIONS="-Djava.awt.headless=true" + (" -Xmx" + heap if heap else ""))
    # a net pre-routed partly on an inner plane layer (presence_link's run on
    # a wide card): the DSN has no inner track, so Freerouting sees the rest
    # dangling and trims it, and the import drops the inner track. Such a net
    # is restored whole, as it was pre-routed.
    tracks = board.Tracks()
    items = [tracks[i].Cast() for i in range(len(tracks))]
    held = {t.GetNetname() for t in items
            if t.Type() == pcbnew.PCB_TRACE_T and t.GetLayer() not in (pcbnew.F_Cu, pcbnew.B_Cu)}
    # copies: GetStart() is a view into the item, which is removed below
    inner = [(t.Type() == pcbnew.PCB_VIA_T, pcbnew.VECTOR2I(t.GetStart().x, t.GetStart().y),
              pcbnew.VECTOR2I(t.GetEnd().x, t.GetEnd().y), t.GetWidth(), t.GetLayer(), t.GetNet(),
              t.GetDrillValue() if t.Type() == pcbnew.PCB_VIA_T else 0)
             for t in items if t.GetNetname() in held]
    if replay is not None:
        ses = _replay_session(board, workdir, replay, preroute_board)
    else:
        for attempt in range(0 if parallel else tries):
            # each try orders the problem differently (a UUID salt): Freerouting
            # can stall on one order and complete on another, and the salt keeps
            # every run of the pipeline the same
            stable_uuids(board, salt + attempt)
            if not pcbnew.ExportSpecctraDSN(board, dsn):
                raise RuntimeError("DSN export failed")
            with open(dsn) as f:
                text = canonical_dsn(f.read(), salt + attempt)
            with open(dsn, "w") as f:
                f.write(text)
            if os.path.exists(ses):
                os.remove(ses)
            # one optimiser thread: with a pool, the route (and whether it
            # completes) changes from run to run
            r = run(_freerouting_cmd(dsn, ses, passes * (attempt + 1), fanout), env=env)
            with open(os.path.join(workdir, "freerouting.log"), "w") as f:
                f.write(r.stdout + r.stderr)
            left = [n for n in re.findall(r"Net '([^']+)' \(\d+ unrouted", r.stdout + r.stderr) if n not in pours]
            if not left and os.path.exists(ses):
                break
        else:
            if not parallel:
                raise RuntimeError("Freerouting left %s unrouted after %d tries (see freerouting.log)" % (left, tries))
        if parallel:
            ses, chosen = _route_parallel(board, workdir, passes, pours, tries, salt, parallel, env, timeout, fanout)
            stable_uuids(board, chosen)                 # the ordering that session was routed on
    if not os.path.exists(ses):
        raise RuntimeError("Freerouting wrote no session file")
    placement = None
    if replay is not None:
        placement = tuple(sorted((f.GetReference(), f.GetPosition().x, f.GetPosition().y,
                                  f.GetOrientationDegrees(), f.IsFlipped())
                                 for f in board.GetFootprints()))
    if not pcbnew.ImportSpecctraSES(board, ses):
        raise RuntimeError("SES import failed")
    if placement is not None:
        after = tuple(sorted((f.GetReference(), f.GetPosition().x, f.GetPosition().y,
                              f.GetOrientationDegrees(), f.IsFlipped())
                             for f in board.GetFootprints()))
        # Specctra coordinates round a few 1 nm KiCad placement artifacts to
        # the nearest grid unit during import. Preserve the guard against a
        # real move, rotation, flip or missing footprint.
        if (len(placement) != len(after) or any(
                before[0] != current[0] or abs(before[1] - current[1]) > 1 or
                abs(before[2] - current[2]) > 1 or before[3:] != current[3:]
                for before, current in zip(placement, after))):
            raise RuntimeError('SES replay moved a pre-routed footprint')
    # the router's own copper on those nets stays (removing it opened every
    # connection it made: the main board's VBUS_F, pre-routed on In3); what
    # the import dropped of the pre-routing goes back
    tracks = board.Tracks()
    have = set()
    for t in [tracks[i] for i in range(len(tracks)) if tracks[i].GetNetname() in held]:
        via = t.Type() == pcbnew.PCB_VIA_T
        have.add((via, t.GetStart().x, t.GetStart().y) + (() if via else (t.GetEnd().x, t.GetEnd().y, t.GetLayer())))
    for is_via, start, end, width, layer, net, drill in inner:
        if (is_via, start.x, start.y) + (() if is_via else (end.x, end.y, layer)) in have:
            continue
        if is_via:
            t = pcbnew.PCB_VIA(board)
            t.SetPosition(start)
            t.SetDrill(drill)
        else:
            t = pcbnew.PCB_TRACK(board)
            t.SetStart(start)
            t.SetEnd(end)
            t.SetLayer(layer)
        t.SetWidth(width)
        t.SetNet(net)
        t.SetLocked(True)
        board.Add(t)
    remove_dangling(board, pours)
    # the import can pair one net class's via diameter with another's drill
    # (0.6 mm with 0.4 mm: a 0.1 mm ring, under JLC's 0.13): keep a 0.15 mm ring
    tracks = board.Tracks()                      # indexed: iterating it breaks on Python 3.14
    for v in [tracks[i].Cast() for i in range(len(tracks)) if tracks[i].Type() == pcbnew.PCB_VIA_T]:
        if v.GetWidth(pcbnew.F_Cu) - v.GetDrillValue() < pcbnew.FromMM(0.3):
            v.SetDrill(v.GetWidth(pcbnew.F_Cu) - pcbnew.FromMM(0.3))
    join_track_ends_to_vias(board)


def join_track_ends_to_vias(board):
    """A track Freerouting ends on (or just touching) the rim of a via of its
    net, not its centre, meets it through a sliver (0.086 mm seen, under
    JLC's 0.09): a stub of the track's width from that end to the via's
    centre, inside the two, so nothing else moves. Returns the count."""
    import pcbnew
    tracks = board.Tracks()                      # indexed: iterating it breaks on Python 3.14
    items = [tracks[i].Cast() for i in range(len(tracks))]
    vias = [v for v in items if v.Type() == pcbnew.PCB_VIA_T]
    n = 0
    for t in [t for t in items if t.Type() == pcbnew.PCB_TRACE_T]:
        for end in (t.GetStart(), t.GetEnd()):
            for v in vias:
                c, r = v.GetPosition(), v.GetWidth(pcbnew.F_Cu) // 2
                d = (end - c).EuclideanNorm()
                # the end inside the via, or its round cap overlapping the rim
                if v.GetNetCode() == t.GetNetCode() and pcbnew.FromMM(0.02) < d <= r + t.GetWidth() // 2:
                    s = pcbnew.PCB_TRACK(board)
                    s.SetStart(end)
                    s.SetEnd(c)
                    s.SetWidth(t.GetWidth())
                    s.SetLayer(t.GetLayer())
                    s.SetNet(t.GetNet())
                    board.Add(s)
                    n += 1
                    break
    return n


def ground_fingers(board, net, tab_top, rise=1.0, rise_top=4.5, width=0.5, via=0.6, drill=0.3):
    """Tie every `net` finger of each card-edge footprint into the body: a
    locked track on the finger's own layer, from its top up into the pour
    `rise` mm above the tab. Pours alone can't reach fingers the key notch
    and neighbouring signals cut off. A column (An facing Bn) gets a via at
    the track's end when both its fingers are on `net` or the other is
    unused: a via there blocks nobody, and it joins the layers where a strip
    of pour is too narrow for a stitching via. Top-side (B) ties rise
    `rise_top`, past the presence link's bottom-layer run, and end in a via
    onto the bottom pour above it: below that run the fingers' strips of
    pour are fenced in on both layers. Returns the fingers tied."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    ni = board.FindNet(net)
    n = 0
    for fp in board.GetFootprints():
        if not str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge"):
            continue
        pads = {p.GetNumber(): p for p in fp.Pads()}
        done = set()
        for num, pad in pads.items():
            if pad.GetNetname() != net:
                continue
            x = to(pad.GetPosition().x)
            top = to(pad.GetBoundingBox().GetTop())
            front = pad.IsOnLayer(pcbnew.F_Cu)
            end = tab_top - (rise_top if front else rise)
            t = pcbnew.PCB_TRACK(board)
            t.SetStart(pcbnew.VECTOR2I(mm(x), mm(top + width / 2)))
            t.SetEnd(pcbnew.VECTOR2I(mm(x), mm(end)))
            t.SetWidth(mm(width))
            t.SetLayer(pcbnew.F_Cu if front else pcbnew.B_Cu)
            t.SetNet(ni)
            t.SetLocked(True)
            board.Add(t)
            n += 1
            if front:
                v = pcbnew.PCB_VIA(board)
                v.SetPosition(pcbnew.VECTOR2I(mm(x), mm(end)))
                v.SetWidth(mm(via))
                v.SetDrill(mm(drill))
                v.SetNet(ni)
                v.SetLocked(True)
                board.Add(v)
            facing = pads.get(("B" if num.startswith("A") else "A") + num[1:])
            unused = facing is None or not facing.GetNetname() or facing.GetNetname().startswith("unconnected-")
            if num[1:] not in done and (unused or facing.GetNetname() == net):
                done.add(num[1:])
                v = pcbnew.PCB_VIA(board)
                v.SetPosition(pcbnew.VECTOR2I(mm(x), mm(tab_top - rise)))
                v.SetWidth(mm(via))
                v.SetDrill(mm(drill))
                v.SetNet(ni)
                v.SetLocked(True)
                board.Add(v)
    return n


def _pad_gap(x, y, box):
    """Distance (mm) from (x, y) to the axis-aligned box (x0, y0, x1, y1): 0 inside."""
    return math.hypot(max(box[0] - x, 0.0, x - box[2]), max(box[1] - y, 0.0, y - box[3]))


def _mask_openings(board):
    """Every pad with a solder-mask opening, as (REF.PAD, (x0, y0, x1, y1) in
    mm): the pad's bounding box grown by the board's mask expansion (a
    rotated pad's box is a little generous, never short). NPTH holes are left
    out: they are holes, not openings over copper."""
    import pcbnew
    to = pcbnew.ToMM
    out = []
    for fp in board.GetFootprints():
        for p in fp.Pads():
            if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                continue
            if not (p.IsOnLayer(pcbnew.F_Mask) or p.IsOnLayer(pcbnew.B_Mask)):
                continue
            bb = p.GetBoundingBox()
            g = SOLDER_MASK_EXPANSION
            out.append(("%s.%s" % (fp.GetReference(), p.GetNumber()),
                        (to(bb.GetLeft()) - g, to(bb.GetTop()) - g, to(bb.GetRight()) + g, to(bb.GetBottom()) + g)))
    return out


def vias_in_pad_openings(board, clear=0.1, allowed=()):
    """Vias whose drill is inside, or within `clear` mm of, a pad's solder-mask
    opening: an open hole in a pad. JLC's SMT line wicks solder down such a
    hole (its own words: "flows into the vias and may cause weak soldering"),
    and plugging it costs extra on 4 layers. A tented via beside a pad
    (copper touching it is fine) does not count. `allowed` are "REF.PAD"
    names the board accepts (an exposed pad's thermal via, audit I3).
    Returns ["REF.PAD via at x,y", ...]."""
    import pcbnew
    to = pcbnew.ToMM
    openings = _mask_openings(board)
    tracks = board.Tracks()
    bad = []
    for v in [tracks[i].Cast() for i in range(len(tracks)) if tracks[i].Type() == pcbnew.PCB_VIA_T]:
        x, y = to(v.GetPosition().x), to(v.GetPosition().y)
        need = to(v.GetDrillValue()) / 2 + clear
        for name, box in openings:
            if name not in allowed and _pad_gap(x, y, box) < need - 1e-4:
                bad.append("%s via at %.2f,%.2f" % (name, x, y))
    return bad


def ground_fanout(board, net, via=0.6, drill=0.3, track=0.3, gap=0.2, margin=0.0, pad_clear=None, in_pad_ok=()):
    """Before routing, give every SMD pad on `net` (edge fingers aside) a
    short track to its own via, pointing away from a small part's centre
    (towards a big one's), so the
    router routes round it instead of walling it in (a pad boxed in by
    signals reaches the pour through a sliver or not at all). No sharing a
    neighbour's via: a signal routed between them would cut the pad off.
    `margin` > 0 keeps each via that much further from other nets' pads, a
    further 0.3 mm from NPTH holes, and `gap` + `margin` from its own net's
    pads too: Freerouting holds a via's hole to the clearance from every
    pad, its own net's included (its DRC: "hole clearance"), draws a via as
    an octagon round its circle, and gets each NPTH hole as a keep-out
    already grown by a clearance, then adds its own; each of those vias
    KiCad passes stayed a violation for the whole run (~1 per via: ~117 on
    the main board, found with `freerouting -de board.dsn -drc report.json`).
    `pad_clear` (mm), if given, keeps every via's drill that far outside every
    pad's solder-mask opening, its own pad's and the net's other pads' too
    (no open hole in a pad: JLC via-in-pad, audit I3/I5/I6), and looks for the
    nearest such spot in any direction, on a 0.05 mm grid, when the fixed fan
    of radii and angles has none (it lands vias in a neighbouring pad of the
    same net, in a row of 0.8 mm-pitch module pads, and in a big pad). The via
    then sits beside its pad on the pad's own short neck. `in_pad_ok` names "REF.PAD"
    pads that keep the old placement, in the pad (an exposed pad's thermal
    via, an accepted open hole). Returns the vias placed."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    ni = board.FindNet(net)
    pads = [(p, fp) for fp in board.GetFootprints() for p in fp.Pads()
            if not str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge")]
    others = []                                   # other nets' pads, grown for a via / a track
    own = []                                      # this net's pads (kept off with `margin`)
    for p, _ in pads:
        if margin and p.GetNetname() == net and p.IsOnCopperLayer():
            bb = p.GetBoundingBox()
            own.append((to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom())))
        # not paste-only apertures (a QFN's exposed-pad stencil windows): no
        # copper, no hole, no net, but they would keep every via off the
        # exposed pad. Holes (NPTH pegs) still count.
        if p.GetNetname() != net and (p.IsOnCopperLayer() or p.GetDrillSize().x > 0):
            bb = p.GetBoundingBox()
            others.append((to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom()),
                           0.3 if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH else 0.0))
    zs = board.Zones()
    for z in [zs[i] for i in range(len(zs))]:
        # the logo's keep-out (silk_keepout): no fan-out via or track under it
        if z.GetIsRuleArea() and z.GetZoneName() == "logo":
            bb = z.GetBoundingBox()
            others.append((to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom()), 0.0))
    openings = _mask_openings(board) if pad_clear is not None else []
    # the hole's clearance, and the via's copper clear of the pad too: a ring that just clips
    # a pad's corner leaves a sliver of copper (KiCad: connection too narrow), and the neck joins them
    hole_reach = max(drill / 2 + (pad_clear or 0.0), via / 2 + 0.02)
    vias = []
    edge = board.GetBoardEdgesBoundingBox()
    ex0, ey0, ex1, ey1 = to(edge.GetLeft()) + 0.8, to(edge.GetTop()) + 0.8, to(edge.GetRight()) - 0.8, to(edge.GetBottom()) - 0.8
    tracks = board.Tracks()
    locked = [(to(tracks[i].GetStart().x), to(tracks[i].GetStart().y), to(tracks[i].GetEnd().x),
               to(tracks[i].GetEnd().y), tracks[i].GetNetname()) for i in range(len(tracks))]

    def clear_of(x, y, grow, m=0.0):
        return not any(b[0] - g < x < b[2] + g and b[1] - g < y < b[3] + g
                       for b in others for g in (grow + (m + b[4] if m else 0.0),))

    def seg_dist(px, py, ax, ay, bx, by):
        dx, dy = bx - ax, by - ay
        t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1e-12)))
        return math.hypot(px - ax - t * dx, py - ay - t * dy)
    n = 0
    for p, fp in pads:
        if p.GetNetname() != net or p.GetAttribute() != pcbnew.PAD_ATTRIB_SMD:
            continue
        cx, cy = to(p.GetPosition().x), to(p.GetPosition().y)
        fx, fy = to(fp.GetPosition().x), to(fp.GetPosition().y)
        base = math.atan2(cy - fy, cx - fx) if math.hypot(cx - fx, cy - fy) > 0.1 else -math.pi / 2
        if len(fp.Pads()) > 8:
            # a module or IC: in, under the part (tented), not out, where a
            # row of GND pins' vias would wall in the pins between them
            base += math.pi
        layer = pcbnew.F_Cu if p.IsOnLayer(pcbnew.F_Cu) else pcbnew.B_Cu
        # a fine-pitch pin (a QFN's TESTEN between two signals) leaves at its own width
        w = min(track, to(min(p.GetSize().x, p.GetSize().y)))
        # after the fan of directions, straight along the pad's long side
        # (its pin's own lane, the only way out between fine-pitch neighbours)
        lane = (math.pi / 2 if p.GetSize().y > p.GetSize().x else 0.0) + (p.GetOrientation().AsRadians())
        if math.cos(lane - base) < 0:
            lane += math.pi
        key = "%s.%s" % (fp.GetReference(), p.GetNumber())
        candidates = [(cx + r * math.cos(a), cy + r * math.sin(a))
                      for r in (1.0, 1.3, 1.6, 2.0)
                      for a in [base + math.radians(da) for da in (0, 30, -30, 60, -60, 90, -90, 135, -135, 180)] + [lane]]
        if pad_clear is not None and key not in in_pad_ok:
            # the fan stays first (a via that already keeps clear stays where it was); only when it
            # has no spot: the nearest one to the pad, within 1.6 mm of it, that keeps the drill off
            # every mask opening; among equals, the way a via would leave this pad anyway
            box = next(b for k, b in openings if k == key)
            found = []
            for ix in range(int((box[0] - 1.6) / 0.05), int((box[2] + 1.6) / 0.05) + 1):
                for iy in range(int((box[1] - 1.6) / 0.05), int((box[3] + 1.6) / 0.05) + 1):
                    vx, vy = ix * 0.05, iy * 0.05
                    d = _pad_gap(vx, vy, box)
                    if d > 1.6:
                        continue
                    dev = abs((math.atan2(vy - cy, vx - cx) - base + math.pi) % (2 * math.pi) - math.pi)
                    found.append((d + 0.25 * dev / math.pi, vx, vy))
            candidates += [(vx, vy) for _, vx, vy in sorted(found)]
        for vx, vy in candidates:
            if not (ex0 < vx < ex1 and ey0 < vy < ey1):
                continue
            if pad_clear is not None and any(_pad_gap(vx, vy, ob) < hole_reach for k, ob in openings
                                             if k != key or key not in in_pad_ok):
                continue
            if not clear_of(vx, vy, via / 2 + gap, margin):
                continue
            if any(b[0] - g < vx < b[2] + g and b[1] - g < vy < b[3] + g
                   for b in own for g in (via / 2 + gap + margin,)):
                continue
            if any(math.hypot(vx - ox, vy - oy) < via + 0.25 for ox, oy in vias):
                continue
            if any(l[4] != net and seg_dist(vx, vy, *l[:4]) < via / 2 + gap + 0.35 for l in locked):   # 0.35: clears another net's via too
                continue
            samples = [(cx + (vx - cx) * i / 12, cy + (vy - cy) * i / 12) for i in range(13)]
            if not all(clear_of(sx, sy, w / 2 + gap) for sx, sy in samples):
                continue
            if any(l[4] != net and seg_dist(sx, sy, *l[:4]) < w / 2 + gap + 0.25
                   for l in locked for sx, sy in samples):
                continue
            t = pcbnew.PCB_TRACK(board)
            t.SetStart(p.GetPosition())
            t.SetEnd(pcbnew.VECTOR2I(mm(vx), mm(vy)))
            t.SetWidth(mm(w))
            t.SetLayer(layer)
            t.SetNet(ni)
            t.SetLocked(True)
            board.Add(t)
            v = pcbnew.PCB_VIA(board)
            v.SetPosition(pcbnew.VECTOR2I(mm(vx), mm(vy)))
            v.SetWidth(mm(via))
            v.SetDrill(mm(drill))
            v.SetNet(ni)
            v.SetLocked(True)
            board.Add(v)
            vias.append((vx, vy))
            n += 1
            break
    return n


def key_escapes(board, tab_top, skip=(), rise=1.0, width=0.2):
    """Pre-route a straight escape for each signal finger beside the key
    notch: a locked track on the finger's own layer from its top to `rise` mm
    above the tab. Those pads sit 0.2 mm from the notch's edge, which
    Freerouting treats as a clearance violation, so it never starts a route
    from them; it joins the track's end instead, but still reports the pad
    unconnected (DRC's connectivity check is the judge of these). `skip`: nets
    tied some other way (the pour). Returns the nets escaped."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    nets = []
    for fp in board.GetFootprints():
        if not str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge"):
            continue
        xs = sorted({round(to(p.GetPosition().x), 3) for p in fp.Pads()})
        beside = {x for i, x in enumerate(xs)
                  if (i > 0 and x - xs[i - 1] > 1.5) or (i + 1 < len(xs) and xs[i + 1] - x > 1.5)}
        for pad in fp.Pads():
            x = round(to(pad.GetPosition().x), 3)
            if x not in beside or not pad.GetNetname() or pad.GetNetname() in skip \
                    or pad.GetNetname().startswith("unconnected-"):
                continue
            tr = pcbnew.PCB_TRACK(board)
            tr.SetStart(pcbnew.VECTOR2I(mm(x), mm(to(pad.GetBoundingBox().GetTop()) + width / 2)))
            tr.SetEnd(pcbnew.VECTOR2I(mm(x), mm(tab_top - rise)))
            tr.SetWidth(mm(width))
            tr.SetLayer(pcbnew.F_Cu if pad.IsOnLayer(pcbnew.F_Cu) else pcbnew.B_Cu)
            tr.SetNet(pad.GetNet())
            tr.SetLocked(True)
            board.Add(tr)
            nets.append(pad.GetNetname())
    return nets


def open_escapes(board, nets):
    """The nets among `nets` whose pads KiCad's connectivity does not join
    into one: what Freerouting's own report cannot be trusted with."""
    board.BuildConnectivity()
    conn = board.GetConnectivity()
    bad = []
    for net in nets:
        pads = [p for fp in board.GetFootprints() for p in fp.Pads() if p.GetNetname() == net]
        if len(pads) < 2:
            continue
        joined = conn.GetConnectedItems(pads[0])
        keys = {(i.GetParentFootprint().GetReference(), i.GetNumber()) for i in joined if i.GetClass() == "PAD"}
        if any((p.GetParentFootprint().GetReference(), p.GetNumber()) not in keys for p in pads[1:]):
            bad.append(net)
    return bad


def clear_fingers(board, nets, margin=0.6):
    """Remove routed tracks of the pour `nets` that reach down over a card's
    fingers (below their top `margin` mm): Freerouting joins neighbouring
    GND fingers with thin wires across the contact surface. ground_fingers
    ties each of them into the pour from its top instead. Returns the count."""
    import pcbnew
    to = pcbnew.ToMM
    areas = []
    for fp in board.GetFootprints():
        if str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge"):
            bb = fp.GetBoundingBox(False)
            top = min(to(p.GetBoundingBox().GetTop()) for p in fp.Pads())
            areas.append((to(bb.GetLeft()), top + margin, to(bb.GetRight()), to(bb.GetBottom())))
    tracks = board.Tracks()                      # indexed: iterating it breaks on Python 3.14
    gone = []
    for tr in [tracks[i].Cast() for i in range(len(tracks))]:
        if tr.Type() != pcbnew.PCB_TRACE_T or tr.IsLocked() or tr.GetNetname() not in nets:
            continue
        for e in (tr.GetStart(), tr.GetEnd()):
            if any(a[0] <= to(e.x) <= a[2] and a[1] <= to(e.y) <= a[3] for a in areas):
                gone.append(tr)
                break
    for tr in gone:
        board.Remove(tr)
        tr.thisown = False
    return len(gone)


def tab_via_keepout(board, tab_top, margin=1.0):
    """A rule area with no vias over each card-edge footprint's finger tab,
    from `tab_top` down past the tab's bottom: Freerouting otherwise drops
    vias between and below the fingers, where the slot's contacts slide and
    the bevel grinds. Tracks (the fingers' escapes) are still allowed."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    n = 0
    for fp in board.GetFootprints():
        if not str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge"):
            continue
        bb = fp.GetBoundingBox(False)
        x0, x1, y1 = to(bb.GetLeft()) - margin, to(bb.GetRight()) + margin, to(bb.GetBottom()) + margin
        z = pcbnew.ZONE(board)
        z.SetIsRuleArea(True)
        z.SetDoNotAllowVias(True)
        z.SetDoNotAllowTracks(False)
        z.SetDoNotAllowPads(False)
        z.SetDoNotAllowZoneFills(False)
        z.SetDoNotAllowFootprints(False)
        z.SetLayerSet(pcbnew.LSET.AllCuMask())
        ol = z.Outline()
        ol.NewOutline()
        for px, py in ((x0, tab_top), (x1, tab_top), (x1, y1), (x0, y1)):
            ol.Append(mm(px), mm(py))
        board.Add(z)
        n += 1
    return n


def presence_link(board, tab_top, rise=3.0, width=0.25, via=0.6, drill=0.3, layer="B.Cu"):
    """Pre-route the presence link every card makes (PRSNT1_n on A1 joined
    to PRSNT2_n on the last B finger): up from A1 on B.Cu, across `rise` mm
    above the tab, a via, and down to the B finger on F.Cu. It must cross
    the other fingers' escapes, and Freerouting gives up on it; the few it
    crosses it routes round. `layer` carries the run across: on a wide card
    whose bottom-side fingers all have signals (the CPU card's address bus),
    or on a 4-layer card whose fingers escape upward on B.Cu (the system
    card), a B.Cu run walls them off, so it goes on an inner layer between
    vias. Returns True if a link was drawn."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    for fp in board.GetFootprints():
        if not str(fp.GetFPID().GetLibNickname()).startswith("Connector_PCBEdge"):
            continue
        pads = {p.GetNumber(): p for p in fp.Pads()}
        last_b = max((k for k in pads if k.startswith("B")), key=lambda k: int(k[1:]))
        a1, bn = pads.get("A1"), pads[last_b]
        if a1 is None or not a1.GetNetname() or a1.GetNetname() != bn.GetNetname():
            continue
        y = tab_top - rise
        ax, bx = to(a1.GetPosition().x), to(bn.GetPosition().x)
        run = board.GetLayerID(layer)
        pts = [(pcbnew.B_Cu, (ax, to(a1.GetBoundingBox().GetTop()) + width / 2), (ax, y)),
               (run, (ax, y), (bx, y)),
               (pcbnew.F_Cu, (bx, y), (bx, to(bn.GetBoundingBox().GetTop()) + width / 2))]
        for layer, a, b in pts:
            t = pcbnew.PCB_TRACK(board)
            t.SetStart(pcbnew.VECTOR2I(mm(a[0]), mm(a[1])))
            t.SetEnd(pcbnew.VECTOR2I(mm(b[0]), mm(b[1])))
            t.SetWidth(mm(width))
            t.SetLayer(layer)
            t.SetNet(a1.GetNet())
            t.SetLocked(True)
            board.Add(t)
        for vx in ((bx,) if run == pcbnew.B_Cu else (ax, bx)):
            v = pcbnew.PCB_VIA(board)
            v.SetPosition(pcbnew.VECTOR2I(mm(vx), mm(y)))
            v.SetWidth(mm(via))
            v.SetDrill(mm(drill))
            v.SetNet(a1.GetNet())
            v.SetLocked(True)
            board.Add(v)
        return True
    return False


UNJOINED = []                            # pour pieces stitch(fragments=True) could not join, for the report


def stitch(board, net, polygon, pitch=4.0, via=0.6, drill=0.3, clearance=0.3, fragments=False):
    """GND stitching: a via on a `pitch` grid inside `polygon` wherever it
    clears every pad, track, other via and the board edge
    by `clearance`, so the pours on each layer are one net and don't leave
    islands. Freerouting adds none. With `fragments`, instead one via in each
    filled piece of the pour that has none, at the first free spot on a fine
    grid: the strips signals cut off, too narrow for the coarse grid to hit.
    Returns the count."""
    import pcbnew
    mm, to = pcbnew.FromMM, pcbnew.ToMM
    ni = board.FindNet(net)
    keep = via / 2 + clearance
    boxes = []                                   # (x0, y0, x1, y1) keep-outs, mm

    def add_box(bb, grow=0.0):
        boxes.append((to(bb.GetLeft()) - grow, to(bb.GetTop()) - grow,
                       to(bb.GetRight()) + grow, to(bb.GetBottom()) + grow))
    # pads, not courtyards: a tented via under a part is fine (Espressif
    # asks for vias under the module's GND pads), and inside a module's pad
    # ring it is the only way that copper joins the rest of the pour
    raw_pads = []                                # (x0, y0, x1, y1, net, pad) as drawn, mm
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            add_box(pad.GetBoundingBox(), keep)
            bb = pad.GetBoundingBox()
            raw_pads.append((to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom()),
                             pad.GetNetname(), pad))
        if not len(fp.Pads()):                   # artwork (the logo): no via through its silkscreen
            add_box(fp.GetBoundingBox(False), keep)
    # nor through a word on the silkscreen (a designator, an LED's word, the
    # board's name), unless a cut-off piece of pour has no other way down:
    # the designator then moves off it (pipeline's fill step)
    words = []
    drawings = board.Drawings()
    texts = [fp.Reference() for fp in board.GetFootprints() if fp.Reference().IsVisible()]
    texts += [d for d in [drawings[i].Cast() for i in range(len(drawings))]
              if d.Type() == pcbnew.PCB_TEXT_T and d.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS)]
    for t in texts:
        x0, y0, x1, y1 = _ink_box(t, via / 2 + 0.25)
        words.append((x0, y0, x1, y1))
    segs = []
    tracks = board.Tracks()                      # indexed: iterating it breaks on Python 3.14
    for t in [tracks[i] for i in range(len(tracks))]:
        if t.Type() == pcbnew.PCB_VIA_T:
            add_box(t.GetBoundingBox(), keep + 0.2)
        else:
            segs.append((to(t.GetStart().x), to(t.GetStart().y), to(t.GetEnd().x), to(t.GetEnd().y),
                         to(t.GetWidth()) / 2 + keep, t.GetNetname(), to(t.GetWidth()) / 2))

    def seg_dist(px, py, ax, ay, bx, by):
        dx, dy = bx - ax, by - ay
        t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1e-12)))
        return math.hypot(px - ax - t * dx, py - ay - t * dy)

    def inside(px, py):                          # even-odd point in polygon
        n, c = len(polygon), False
        for i in range(n):
            (ax, ay), (bx, by) = polygon[i], polygon[(i + 1) % n]
            if (ay > py) != (by > py) and px < ax + (py - ay) * (bx - ax) / (by - ay):
                c = not c
        return c

    def edge_ok(px, py):
        n = len(polygon)
        return all(seg_dist(px, py, *polygon[i], *polygon[(i + 1) % n]) >= keep + 0.3 for i in range(n))
    # the pours as filled now: a via only where copper surrounds it on both
    # layers, else it would dangle in a gap or hold up an island
    pours = [z for z in board.Zones() if z.GetNetname() == net]

    def filled(px, py):
        pt = pcbnew.VECTOR2I(mm(px), mm(py))
        return all(any(z.HitTestFilledArea(layer, pt, 0) for z in pours if z.IsOnLayer(layer))
                   for layer in (pcbnew.F_Cu, pcbnew.B_Cu))
    def ok(x, y, spare_words=True):
        return (inside(x, y) and edge_ok(x, y) and filled(x, y)
                and not any(b[0] < x < b[2] and b[1] < y < b[3] for b in boxes)
                and not (spare_words and any(b[0] < x < b[2] and b[1] < y < b[3] for b in words))
                and all(seg_dist(x, y, *sg[:4]) >= sg[4] for sg in segs))

    def place(x, y):
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
        v.SetWidth(mm(via))
        v.SetDrill(mm(drill))
        v.SetNet(ni)
        board.Add(v)
        boxes.append((x - keep - 0.2, y - keep - 0.2, x + keep + 0.2, y + keep + 0.2))
        return v

    def fan_out(layer, out, other, good, track=0.25, gap=0.2):
        for x0, y0, x1, y1, pnet, pad in raw_pads:
            if pnet != net or not pad.IsOnLayer(layer) or not out.PointInside(pad.GetPosition()):
                continue
            cx, cy = to(pad.GetPosition().x), to(pad.GetPosition().y)
            own = (x0 - keep, y0 - keep, x1 + keep, y1 + keep)
            for r in (0.9, 1.1, 1.3, 1.6, 2.0, 2.5):
                for a in range(0, 360, 15):
                    px, py = cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a))
                    pt = pcbnew.VECTOR2I(mm(px), mm(py))
                    if not (inside(px, py) and edge_ok(px, py) and good(pt)):
                        continue
                    if any(b != own and b[0] < px < b[2] and b[1] < py < b[3] for b in boxes):
                        continue
                    if not all(seg_dist(px, py, *sg[:4]) >= sg[4] for sg in segs):
                        continue
                    # the track from the pad to the via clears every other net
                    samples = [(cx + (px - cx) * i / 20, cy + (py - cy) * i / 20) for i in range(21)]
                    grow = track / 2 + gap
                    if any(q[4] != net and q[0] - grow < sx < q[2] + grow and q[1] - grow < sy < q[3] + grow
                           for q in raw_pads for sx, sy in samples):
                        continue
                    if any(sg[5] != net and seg_dist(sx, sy, *sg[:4]) < sg[6] + grow
                           for sg in segs for sx, sy in samples):
                        continue
                    place(px, py)
                    t = pcbnew.PCB_TRACK(board)
                    t.SetStart(pad.GetPosition())
                    t.SetEnd(pt)
                    t.SetWidth(mm(track))
                    t.SetLayer(layer)
                    t.SetNet(ni)
                    board.Add(t)
                    return True
        return False

    if fragments:
        # the pieces of the pour on every copper layer it covers (inner planes
        # and pours too), and what joins them: the net's vias (all layers),
        # its pads, and its tracks, end to end. A piece counts as reached when
        # it is in one connected group with the biggest outer-layer piece; the
        # others get a via onto reached copper, or are reported
        items = [tracks[i].Cast() for i in range(len(tracks)) if tracks[i].GetNetname() == net]
        vias = [v for v in items if v.Type() == pcbnew.PCB_VIA_T]
        nsegs = [s for s in items if s.Type() == pcbnew.PCB_TRACE_T]
        npads = [pd for fp in board.GetFootprints() for pd in fp.Pads() if pd.GetNetname() == net]
        cu = [board.GetLayerID(board.GetLayerName(l)) for l in board.GetEnabledLayers().CuStack()]
        pieces = []                              # (layer, outline)
        for z in pours:
            for layer in cu:
                if z.IsOnLayer(layer):
                    polys = z.GetFilledPolysList(layer)
                    pieces += [(layer, polys.Outline(i)) for i in range(polys.OutlineCount())]

        def piece_at(layer, pt):
            for k, (ly, out) in enumerate(pieces):
                if ly == layer and out.PointInside(pt):
                    return k
            return None
        # union-find over pieces (0..P-1), then vias, pads and tracks
        P = len(pieces)
        nodes = P + len(vias) + len(npads) + len(nsegs)
        parent = list(range(nodes))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        def join(a, b):
            if a is not None and b is not None:
                parent[find(a)] = find(b)
        for i, v in enumerate(vias):
            for layer in cu:
                join(P + i, piece_at(layer, v.GetPosition()))
        for i, pd in enumerate(npads):
            for layer in cu:
                if pd.IsOnLayer(layer):
                    join(P + len(vias) + i, piece_at(layer, pd.GetPosition()))
        base = P + len(vias) + len(npads)
        for i, s in enumerate(nsegs):
            for end in (s.GetStart(), s.GetEnd()):
                join(base + i, piece_at(s.GetLayer(), end))
                for j, v in enumerate(vias):
                    if v.HitTest(end):
                        join(base + i, P + j)
                for j, pd in enumerate(npads):
                    if pd.IsOnLayer(s.GetLayer()) and pd.HitTest(end):
                        join(base + i, P + len(vias) + j)
                for j, o in enumerate(nsegs):
                    if j != i and o.GetLayer() == s.GetLayer() and o.HitTest(end):
                        join(base + i, base + j)
        outer = [k for k, (ly, _) in enumerate(pieces) if ly in (pcbnew.F_Cu, pcbnew.B_Cu)]
        reached = set()
        if outer:
            root = find(max(outer, key=lambda k: pieces[k][1].Area()))
            reached = {k for k in range(P) if find(k) == root}

        def reached_at(pt, but):
            """a reached piece on another layer at `pt`: where a via joins"""
            return any(piece_at(ly, pt) in reached for ly in cu if ly != but)
        count = 0
        for k, (layer, out) in enumerate(pieces):
            if k in reached:
                continue
            other = pcbnew.B_Cu if layer == pcbnew.F_Cu else pcbnew.F_Cu
            if layer not in (pcbnew.F_Cu, pcbnew.B_Cu):
                other = pcbnew.F_Cu                  # an inner piece: fan out from the top
            bb = out.BBox()
            y = to(bb.GetTop())
            found = None
            for spare in (True, False):
                y = to(bb.GetTop())
                while found is None and y < to(bb.GetBottom()):
                    x = to(bb.GetLeft())
                    while x < to(bb.GetRight()):
                        pt = pcbnew.VECTOR2I(mm(x), mm(y))
                        if out.PointInside(pt) and reached_at(pt, layer) and ok(x, y, spare):
                            found = (x, y)
                            break
                        x += 0.25
                    y += 0.25
                if found:
                    break
            if found:
                place(*found)
                reached.add(k)
                count += 1
                continue
            # no room inside (a pocket between one part's pads): fan out from
            # a pad of the net in it, to a via on reached copper beside it
            fan = fan_out(layer, out, other, lambda pt: reached_at(pt, layer)) \
                if layer in (pcbnew.F_Cu, pcbnew.B_Cu) else False
            if fan:
                reached.add(k)
                count += 1
            else:
                UNJOINED.append("%s piece at %.1f,%.1f..%.1f,%.1f mm" % (
                    board.GetLayerName(layer),
                    to(bb.GetLeft()), to(bb.GetTop()), to(bb.GetRight()), to(bb.GetBottom())))
        return count
    xs = [p[0] for p in polygon]
    ys = [p[1] for p in polygon]
    count = 0
    y = min(ys) + pitch / 2
    while y < max(ys):
        x = min(xs) + pitch / 2
        while x < max(xs):
            if ok(x, y):
                place(x, y)
                count += 1
            x += pitch
        y += pitch
    return count


def fill_zones(board):
    import pcbnew
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())


# ------------------------------------------------------ the I/O card outline
# doc/hardware/slot.md, Mechanical: every I/O card is this shape, in the
# frame of KiCad's BUS_PCIexpress_x1 (finger B1 at the origin, fingers +y)
IO_CARD_BODY = (-6.0, -47.55, 56.0, -4.95)
IO_CARD_TAB = (-0.65, 19.65)             # where the x1 tab meets the body
X8_TAB = (-0.65, 50.65)                  # the CPU card's x8 tab, under the same body (cpu-bus.md, CPU card outline)


def io_card_edge(tab=IO_CARD_TAB):
    """The card body's Edge.Cuts, open where a finger tab spanning x
    tab[0] .. tab[1] meets it (the tab footprint draws the rest)."""
    x0, y0, x1, y1 = IO_CARD_BODY
    return [(tab[0], y1), (x0, y1), (x0, y0), (x1, y0), (x1, y1), (tab[1], y1)]


IO_CARD_EDGE = io_card_edge()
IO_CARD_HOLE = (52.0, -43.55)             # M3, non-plated
IO_CARD_PWR_LED = (-3.0, -44.55)          # the power LED, the same on every board: 3 mm in from top-left
MOUNTING_HOLE = "MountingHole:MountingHole_3.2mm_M3"


def power_led_at(body):
    """Where a board's power LED goes: 3 mm in from its body's top-left
    corner (milestone-1.md, Indicator LEDs)."""
    return (body[0] + 3.0, body[1] + 3.0)


# ---------------------------------------------------------------- pipeline

# footprints that are not parts: nothing to buy, nothing for JLC to place
NOT_PARTS = ("Connector_PCBEdge:", "cupc8:KaplanLabs_Logo", "cupc8:TestPad", "TestPoint:", "MountingHole:")


def jlc_fab(sch, pcb, comps, fab):
    """JLC's assembly files: bom.csv (Comment, Designator, Footprint, LCSC Part #)
    and cpl.csv (Designator, Mid X, Mid Y, Layer, Rotation: KiCad's plus the
    footprint's hw/parts/jlc_rotation.yaml correction). Every part must
    carry an LCSC number, because nothing is fitted by hand."""
    import csv

    def lcsc(c):                          # our field, or the one easyeda2kicad writes
        return c.get("fields", {}).get("LCSC") or c.get("fields", {}).get("LCSC Part")
    missing = sorted(r for r, c in comps.items() if not lcsc(c) and not c["footprint"].startswith(NOT_PARTS))
    if missing:
        raise SystemExit("parts without an LCSC number: %s" % ", ".join(missing))
    placed = {r: c for r, c in comps.items() if lcsc(c)}
    groups = {}
    for r, c in placed.items():
        groups.setdefault((c["value"], c["footprint"], lcsc(c)), []).append(r)
    with open(os.path.join(fab, "bom.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Comment", "Designator", "Footprint", "LCSC Part #"])
        for (val, fp, lcsc), refs in sorted(groups.items(), key=lambda g: g[1][0]):
            w.writerow([val, ",".join(sorted(refs)), fp.split(":")[1], lcsc])
    raw = os.path.join(fab, "kicad-pos.csv")
    run(["kicad-cli", "pcb", "export", "pos", "--format", "csv", "--units", "mm", "--side", "both",
         "-o", raw, pcb])
    import bomcheck
    import assembly_geometry as assembly
    turn = bomcheck.rotations()           # JLC's footprint zero vs KiCad's (hw/parts/jlc_rotation.yaml)
    shift = bomcheck.offsets()            # and its origin, where it is not KiCad's (a pin header's pin 1)
    with open(raw) as f, open(os.path.join(fab, "cpl.csv"), "w", newline="") as g:
        w = csv.writer(g)
        w.writerow(["Designator", "Mid X", "Mid Y", "Layer", "Rotation"])
        for row in csv.DictReader(f):
            if row["Ref"] in placed:
                fp = placed[row["Ref"]]["footprint"]
                side = {"top": "Top", "bottom": "Bottom"}.get(row["Side"])
                if side is None:
                    raise ValueError("unknown native placement side: " + row["Side"])
                rot = assembly.rotation(float(row["Rot"]), turn.get(fp, 0), side)
                mid = (row["PosX"] + "mm", row["PosY"] + "mm")
                if fp in shift:
                    mx, my = assembly.midpoint(float(row["PosX"]), -float(row["PosY"]), float(row["Rot"]), shift[fp], side)
                    mid = ("%.6fmm" % mx, "%.6fmm" % my)
                w.writerow([row["Ref"], mid[0], mid[1], side, "%.6f" % rot])
    os.remove(raw)
    counts = {}
    for (_, _, code), refs in groups.items():
        counts[code] = counts.get(code, 0) + len(refs)
    return counts


def check_stock(counts, boards, margin=2):
    """Every part in JLC's assembly library with `margin` times the stock the
    order needs (`boards` assembled, each part's count per board):
    verification.md 4.8. CUPC8_OFFLINE=1 skips it (and says so)."""
    if os.environ.get("CUPC8_OFFLINE"):
        return "skipped: CUPC8_OFFLINE"
    import jlcparts
    short = []
    for code, n in sorted(counts.items()):
        need = n * boards * margin
        hits = [p for p in jlcparts.query(code, 5) if p["componentCode"] == code]
        if not hits:
            short.append("%s not in JLC's library" % code)
        elif hits[0]["stockCount"] < need:
            short.append("%s: %d in stock, under %dx the %d the order places"
                         % (code, hits[0]["stockCount"], margin, n * boards))
    if short:
        raise SystemExit("JLC stock:\n  " + "\n  ".join(short))
    return "%d parts, %dx stock for %d boards" % (len(counts), margin, boards)


# The do-not-trim note for every card's JLC order (David, 2026-09-28;
# doc/hardware/jlc-order-checklist.md section 3).
FINGER_ORDER_NOTE = ("Gold fingers follow PCIe CEM r3.0 geometry. Do not trim, narrow, shorten or shift any "
                     "gold finger, and do not change the key notch. If your process requires any change, "
                     "contact us before production.")


def order_spec(layers, card_edge, assembly_sides=("Top",)):
    """The JLC order options, written next to the Gerbers as order.json.
    Cards (card_edge) are 1.6 mm with ENIG gold fingers (JLC offers gold
    fingers only on ENIG: David, 2026-09-28) and a 30 degree chamfer
    (milestone-1.md, Board thickness); check_order enforces it. Every board
    asks JLC for its post-CAM files before production (Confirm Production
    File). Cards go to JLC one per panel (JLC's PCBA minimum counts panels);
    the panel's geometry is not generated here yet (doc/m1-live-status.md)."""
    if not assembly_sides or any(s not in ("Top", "Bottom") for s in assembly_sides):
        raise ValueError("assembly sides must be nonempty Top/Bottom selection")
    sides = [s for s in ("Top", "Bottom") if s in assembly_sides]
    text = "top and bottom sides" if len(sides) == 2 else sides[0].lower() + " side"
    spec = {"layers": layers, "thickness_mm": 1.6, "surface_finish": "ENIG", "min_hole_mm": 0.3,
            "finished_outer_copper_oz": 1,
            "assembly": "PCBA " + text + ", parts from bom.csv/cpl.csv, all LCSC",
            "assembly_sides": sides,
            "pcba_type": "Standard",       # gold fingers and THT parts rule out Economic
            "confirm_production_file": True,
            "solder_mask_colour": "green",  # black/white need a 0.13 mm web; main U2 is exactly there
            "stencil_remark": "stencil apertures as supplied in the paste layers (RP2040 exposed-pad windowpane)",
            "gold_fingers": card_edge, "finger_finish": "ENIG" if card_edge else None,
            "finger_chamfer_deg": 30 if card_edge else None}
    if card_edge:
        spec["cards_per_panel"] = 1
        spec["outline_tolerance_mm"] = 0.1     # JLC high precision: MECH-101's 0.10 mm notch gap assumes it
        spec["order_note"] = FINGER_ORDER_NOTE
    else:
        spec["edge_rails"] = "left and right (188 mm) edges only: J1 overhangs the bottom edge"
    if layers > 2:
        spec["finished_inner_copper_oz"] = 0.5
    # JLC's standard 1.6 mm stack-ups (jlcpcb.com/impedance); gold fingers
    # are offered at any layer count, with ENIG and a board >= 50 mm
    stackup = {4: "JLC04161H-7628", 6: "JLC06161H-3313"}.get(layers)
    if stackup:
        spec["stackup"] = stackup
        spec["impedance_control"] = True       # the SI models use this stackup's dielectric
    return spec


def check_order(spec, card_edge, assembly_sides=None):
    bad = []
    sides = spec.get("assembly_sides", ["Top"])
    if not isinstance(sides, list) or not sides or len(set(sides)) != len(sides) or any(s not in ("Top", "Bottom") for s in sides):
        bad.append("assembly sides must identify physical Top/Bottom selection")
    else:
        text = "top and bottom sides" if len(sides) == 2 else sides[0].lower() + " side"
        if spec.get("assembly") != "PCBA " + text + ", parts from bom.csv/cpl.csv, all LCSC":
            bad.append("assembly order description differs from selected sides")
        if assembly_sides is not None and set(sides) != set(assembly_sides):
            bad.append("assembly order sides differ from fitted CPL sides")
    if spec["thickness_mm"] != 1.6:
        bad.append("thickness %s mm, cards must be 1.6" % spec["thickness_mm"])
    if spec.get("finished_outer_copper_oz") != 1:
        bad.append("finished outer copper must be 1 oz")
    if spec["layers"] > 2 and spec.get("finished_inner_copper_oz") != 0.5:
        bad.append("finished inner copper must be 0.5 oz")
    if card_edge and (not spec["gold_fingers"] or spec["finger_finish"] != "ENIG"
                      or spec["surface_finish"] != "ENIG" or spec["finger_chamfer_deg"] != 30):
        bad.append("card edge needs ENIG gold fingers with a 30 degree chamfer")
    if card_edge and (spec.get("cards_per_panel") != 1 or spec.get("outline_tolerance_mm") != 0.1
                      or spec.get("order_note") != FINGER_ORDER_NOTE):
        bad.append("card edge needs one card per panel, 0.1 mm outline tolerance and the do-not-trim note")
    if not spec.get("confirm_production_file") or spec.get("pcba_type") != "Standard":
        bad.append("every board needs Confirm Production File and Standard PCBA")
    if spec.get("stackup") and not spec.get("impedance_control"):
        bad.append("a board with a named stackup needs impedance control")
    if bad:
        raise SystemExit("fab order: " + "; ".join(bad))


def pipeline(name, schematic, placement, outline, out=None, zones=("/GND",), power_nets=(),
             graphics=(), edge=None, layers=2, footprint_libs=("cupc8",), passes=40, card_edge=False,
             zone_outline=None, boards=2, labels=None, title=None, revision=None, revision_at=None,
             io_card=False, prepare=None, presence=None, fine_nets=(), plane=False, route_tries=3,
             tab=IO_CARD_TAB, silk_text=None, logo_keepout=False, route_parallel=0, fanout_margin=0.0, route_fanout=True,
             fine_power_nets=(), label_side=None, route_timeout=None, route_heap=None, zone_min_width=None, dense_nets=(),
             post_route=None, replay=None, seeded_route=None, pad_via_clear=None, pad_via_ok=(), post_fill=None, designator_reach=None):
    """Schematic -> ERC -> netlist -> board -> Freerouting -> zones -> silk and
    3D-model checks -> DRC with schematic parity -> Gerbers, drill, JLC BOM and
    CPL -> BOM check (bomcheck.py) -> JLC stock for `boards` assembled -> 3D
    renders. `schematic(path, footprint_libs)` writes the sheet. Returns {LCSC number: count per board}.

    Every board carries its name and revision (doc/milestone-1.md, Board
    revision): `title` and `revision` are printed as "<title> rev <revision>"
    on the top silkscreen, in the body's bottom-right corner unless
    `revision_at` names another bottom-right anchor (mm), and go in the
    board's title block, which the Gerbers' X2 attributes carry.

    `prepare(board)`, if given, runs after the pad fan-out and before
    Freerouting: a board's own locked pre-routing (layer changes the router
    would otherwise scatter). The nets it returns, if any, are finger escapes
    of its own, which Freerouting may report open: they are checked on KiCad's
    connectivity after routing, as the key-notch escapes are.

    `seeded_route(board, workdir)`, if given, puts the board's own recorded
    route on the pre-route board (a hand-route seed) and returns how many
    connections are still unrouted. At 0 Freerouting is not run at all; above
    0 it runs as usual, the recorded copper being fixed wiring, so it lays
    only what is left.

    `post_route(board)`, if given, makes deterministic board-specific copper
    corrections after SES import and before connectivity/DRC checks and pours.

    `replay`, for the main board only, is a validated sesreplay snapshot. It
    imports that one content-bound SES without invoking Freerouting, then
    continues through the same post-route and fabrication steps.

    `pad_via_clear` (mm, e.g. 0.1): no via's drill inside or nearer than this
    to a pad's solder-mask opening, JLC's via-in-pad rule (ground_fanout
    places them so, and the step after the pours fails on any that is not).
    `pad_via_ok`: "REF.PAD" names exempt (an exposed pad's thermal via, which
    stays open in the pad: audit I3). Left off, the board is built as before.

    `logo_keepout`: no tracks or vias on the copper under the logo (silk_keepout),
    and the silkscreen step fails on any there.

    `zone_min_width` (mm): the pours' minimum width, if not build_board's
    0.25 (KiCad's fill at 0.25 left the main board's planes a 0.063 mm neck
    that its own connection-width check then flagged; at 0.3 it does not)."""
    import pcbnew
    if replay is not None and name != 'main':
        raise ValueError('SES replay is supported only for the main board')
    if io_card:
        # every I/O card is the same shape (slot.md, Mechanical): the outline,
        # finger edge and pour come from here, and the parts every card has in
        # the same place are checked
        # (the CPU card too, on its x8 tab: `tab` is where the tab meets the body)
        if outline not in (None, IO_CARD_BODY) or edge not in (None, io_card_edge(tab)):
            raise SystemExit("%s: an I/O card has the standard outline (IO_CARD_BODY/EDGE), not its own" % name)
        outline, edge, card_edge = IO_CARD_BODY, io_card_edge(tab), True
        zone_outline = zone_outline or card_zone(IO_CARD_BODY, tab, -1.5)
        for ref, want in (("J1", (0, 0, 0)), ("H1", IO_CARD_HOLE + (0,)), ("D1", IO_CARD_PWR_LED + (0,))):
            if tuple(placement.get(ref, ())[:3]) != want:
                raise SystemExit("%s: an I/O card has %s at %s (slot.md, Mechanical), not %s" % (
                    name, ref, want, placement.get(ref)))
    if not (title and revision):
        raise SystemExit("%s: every board needs a title and a revision (doc/milestone-1.md, Board revision)" % name)
    revision_at = revision_at or (outline[2] - 1.0, outline[3] - 1.0)
    out = os.path.abspath(out or os.path.join(ROOT, "build", "hw", name))
    os.makedirs(out, exist_ok=True)
    sch, pcb, pro = (os.path.join(out, name + e) for e in (".kicad_sch", ".kicad_pcb", ".kicad_pro"))
    import boardevidence
    evidence_inputs = boardevidence.inputs(name)
    receipt = os.path.join(out, "evidence.json")
    if os.path.exists(receipt):
        os.unlink(receipt)  # a failed rebuild must invalidate the old success
    state = {}
    # the nets the pours join (not routed): a "routed" pour's net is routed
    pour_nets = list(dict.fromkeys(z if isinstance(z, str) else z[0] for z in zones
                                   if isinstance(z, str) or len(z) < 3 or z[2] != "routed"))

    def step(label, fn):
        print("%-28s" % label, end=" ", flush=True)
        r = fn()
        print("ok" + (" (%s)" % r if r else ""))

    def sheet():
        schematic(sch, footprint_libs)
        write_project(pro, power_nets=power_nets, fine_nets=fine_nets, fine_power_nets=fine_power_nets,   # before ERC: it carries the library tables
                      rules=JLC_RULES_4 if layers >= 4 else None, dense_nets=dense_nets)
    step("schematic", sheet)
    step("ERC", lambda: run(["kicad-cli", "sch", "erc", "--format", "json", "--severity-all",
                             "--exit-code-violations", "-o", os.path.join(out, "erc.json"), sch]) and None)

    def netlist():
        c, n = export_netlist(sch, os.path.join(out, name + ".net"))
        state["c"] = {r: v for r, v in c.items() if not r.startswith("#")}
        state["n"] = n
        return "%d parts, %d nets" % (len(state["c"]), len(n))
    step("netlist", netlist)

    def build():
        b = build_board(state["c"], state["n"], placement, outline, layers=layers, zones=zones,
                        graphics=graphics, edge=edge, zone_outline=zone_outline, labels=labels,
                        label_side=label_side, designator_reach=designator_reach,
                        plane=plane, silk_text=silk_text, logo_keepout=logo_keepout, power_nets=power_nets)
        state["silk_widened"] = normalize_silk_strokes(b)
        mark_revision(b, title, revision, revision_at)
        if card_edge:
            state["fingers"] = ground_fingers(b, pour_nets[0], outline[3])
            if callable(presence):      # the board routes the link itself, before the fan-out
                presence(b)
            else:
                presence_link(b, outline[3], **(presence or {}))   # e.g. {"layer": "In2.Cu"}
            tab_via_keepout(b, outline[3])
            state["escaped"] = key_escapes(b, outline[3], skip=pour_nets)
        # every poured net's pads get a via: GND, and any net on a plane
        # (build_board's (net, layers) zones), which is reached no other way
        state["fanout"] = sum(ground_fanout(b, n, margin=fanout_margin, pad_clear=pad_via_clear,
                                                 in_pad_ok=pad_via_ok) for n in pour_nets)
        if prepare:                   # the board's own locked pre-routing, before Freerouting
            # nets it returns are escapes of its own: checked like the key-notch ones
            state["escaped"] = list(state.get("escaped", [])) + list(prepare(b) or [])
        # the fixed vias are in (finger ties, presence link, fan-out, the
        # board's own): designators and the name move off them. A name that
        # had to move (off a wide tab's ties) has its new spot kept free of
        # the router's vias; one that didn't is left to the router as before
        # (a keep-out changes the routing) and moves after it if it must
        state["pre_moved"] = place_designators(b, outline, labels, silk_text=silk_text, reseat=True,
                                               label_side=label_side)
        if any(" rev " in m for m in state["pre_moved"]):
            name_keepout(b)
        pcbnew.SaveBoard(pcb, b, True)
        state["b"] = pcbnew.LoadBoard(pcb)
        return ("%d GND fingers tied to the pour, " % state["fingers"] if card_edge else "") + \
            "%d GND pad vias" % state["fanout"] + \
            ("; %d thin silk strokes normalized" % state["silk_widened"] if state["silk_widened"] else "") + \
            ("; designators moved off them: " + " ".join(state["pre_moved"]) if state["pre_moved"] else "")
    step("board", build)
    def route():
        # Freerouting reports the key-notch escapes' nets unrouted whether or
        # not it reached them, so they are taken on trust and then checked
        # here, on KiCad's own connectivity: a try that left one open is
        # thrown away and the router runs again with more passes
        # Freerouting also, now and then, lays a track closer to a fixed via
        # than the two nets' classes allow (a Fine track by a Default via):
        # KiCad's DRC on the routed copper throws such a try away too
        escaped = tuple(state.get("escaped", ()))
        routed = os.path.join(out, name + "-routed.kicad_pcb")
        seeded = False
        for round_ in range(1 if replay is not None else 3):
            if round_:
                state["b"] = pcbnew.LoadBoard(pcb)       # the board as built, unrouted
            try:
                if seeded_route and replay is None and not round_ and seeded_route(state["b"], out) == 0:
                    seeded = True            # the seeds route every connection: no router run
                else:
                    autoroute(state["b"], out, passes, pours=tuple(pour_nets) + escaped,
                              salt=route_tries * max(1, route_parallel) * round_, tries=route_tries,
                              parallel=route_parallel, timeout=route_timeout, heap=route_heap,
                              replay=replay, preroute_board=pcb, fanout=route_fanout)
            except RuntimeError as e:        # nets left unrouted: the next round's orderings
                if replay is not None:
                    raise
                open_nets, too_close = [str(e)], []
                continue
            if post_route:
                post_route(state["b"])
            open_nets = open_escapes(state["b"], escaped)
            too_close = []
            if not open_nets:
                pcbnew.SaveBoard(routed, state["b"])
                report = os.path.join(out, "drc-routed.json")
                subprocess.run(["kicad-cli", "pcb", "drc", "--format", "json", "-o", report, routed],
                               capture_output=True)
                import json
                too_close = [v["description"] for v in json.load(open(report))["violations"]
                             if v["type"] == "clearance"]
                if not too_close:
                    break
            if seeded:                       # the recorded route is wrong: hours of the router would not fix that
                raise RuntimeError("the recorded route left %s open or copper too close (%s)" %
                                   (open_nets, "; ".join(too_close[:3])))
        else:
            if replay is not None:
                raise RuntimeError('SES replay left %s open or copper too close (%s)' %
                                   (open_nets, '; '.join(too_close[:3])))
            raise RuntimeError("Freerouting left %s unrouted, or copper too close (%s), over 3 rounds of %d tries"
                               % (open_nets, "; ".join(too_close[:3]), route_tries))
        n = clear_fingers(state["b"], pour_nets) if card_edge else 0
        # the routed board, before the pours: what the later steps start from
        pcbnew.SaveBoard(routed, state["b"])
        return ("%d pour tracks cleared off the fingers" % n if n else "") + \
            (" (round %d: the ones before had copper too close)" % (round_ + 1) if round_ else "")
    step("autoroute", route)

    def fill():
        # designators the fan-out's or the router's vias landed under move
        # clear of them first; the stitching vias then keep off every one
        moved = place_designators(state["b"], outline, labels, silk_text=silk_text, reseat=True,
                                  label_side=label_side)
        # the name's via keep-out has done its work for the router (and is
        # stale if the name moved); the stitching keeps off the name by itself
        zs = state["b"].Zones()
        for z in [zs[i] for i in range(len(zs)) if zs[i].GetZoneName() == "revision"]:
            state["b"].Remove(z)
        x0, y0, x1, y1 = outline
        # the body only: no vias on a card's finger tab, even where the pour reaches it
        poly = [(x0 + .5, y0 + .5), (x1 - .5, y0 + .5), (x1 - .5, y1 - .5), (x0 + .5, y1 - .5)]
        # fill once keeping islands, so both layers' pours exist wherever
        # there is room (a layer with no pads of its own would otherwise be
        # dropped whole as an island), stitch where both have copper, then
        # fill again removing whatever still floats
        zs = list(state["b"].Zones())
        for z in zs:
            z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_NEVER)
            if zone_min_width and not z.GetIsRuleArea():
                z.SetMinThickness(pcbnew.FromMM(zone_min_width))
        fill_zones(state["b"])
        n = sum(stitch(state["b"], z, poly, pitch=3.0) for z in zones[:1])   # the first pour net (GND)
        for z in zs:
            z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
        fill_zones(state["b"])
        for _ in range(3):                      # then any piece signals cut off, until none is left
            del UNJOINED[:]
            k = sum(stitch(state["b"], z, poly, fragments=True) for z in zones[:1])
            if not k:
                break
            n += k
            fill_zones(state["b"])
        moved += place_designators(state["b"], outline, labels, silk_text=silk_text, reseat=True,
                                   label_side=label_side)
        if post_fill is not None:
            # This hook edits actual filled polygons. Do not refill afterward:
            # DRC, plotted proof and electrical qualification inspect these fills.
            import json
            audit = post_fill(state["b"])
            with open(os.path.join(out, "post-fill-audit.json"), "w") as stream:
                json.dump(audit, stream, indent=2)
                stream.write("\n")
        pcbnew.SaveBoard(pcb, state["b"])
        return "%d stitching vias" % n + ("; designators moved off vias: " + " ".join(moved) if moved else "") + \
            ("; NOT JOINED: " + "; ".join(UNJOINED) if UNJOINED else "")
    step("stitch + zones + save", fill)

    def open_holes():
        bad = vias_in_pad_openings(state["b"], pad_via_clear, pad_via_ok)
        if bad:
            raise SystemExit("vias with their drill in a pad's mask opening (JLC via-in-pad):\n  " + "\n  ".join(bad))
    if pad_via_clear is not None:
        step("no open via in a pad", open_holes)

    def silk():
        bad = check_silk(state["b"], artwork=logo_keepout, labels=labels) + check_models()
        if bad:
            raise SystemExit("silkscreen / 3D models:\n  " + "\n  ".join(bad))
    step("silkscreen, 3D models", silk)
    step("DRC + schematic parity", lambda: run(
        ["kicad-cli", "pcb", "drc", "--format", "json", "--schematic-parity", "--severity-all",
         "--exit-code-violations", "-o", os.path.join(out, "drc.json"), pcb]) and None)

    fab = os.path.join(out, "fab")
    os.makedirs(fab, exist_ok=True)

    def gerbers():
        # only what JLC fabricates from: copper, mask, paste, silkscreen, outline
        cu = ",".join(["F.Cu", "B.Cu"] + ["In%d.Cu" % i for i in range(1, layers - 1)])
        run(["kicad-cli", "pcb", "export", "gerbers", "--layers",
             cu + ",F.Mask,B.Mask,F.Paste,B.Paste,F.SilkS,B.SilkS,Edge.Cuts", "-o", fab + "/", pcb])
        run(["kicad-cli", "pcb", "export", "drill", "-o", fab + "/", pcb])
        return "%d files" % len(os.listdir(fab))
    step("gerbers + drill", gerbers)

    def bom():
        state["lcsc"] = jlc_fab(sch, pcb, state["c"], fab)
        return "%d distinct parts" % len(state["lcsc"])
    step("JLC BOM + CPL", bom)

    def parts():                          # verification 4.3 and 4.8's BOM <-> schematic (BRD-001)
        import bomcheck
        return bomcheck.check(name, out)
    step("BOM: parts, pins, rotations", parts)
    def stock():
        result = check_stock(state["lcsc"], boards)
        state["stock_result"] = result
        state["stock_skipped"] = bool(os.environ.get("CUPC8_OFFLINE"))
        return result
    step("JLC stock", stock)

    def order():
        import json
        import csv
        with open(os.path.join(fab, "cpl.csv"), newline="") as placement_file:
            sides = {row["Layer"] for row in csv.DictReader(placement_file)}
        spec = order_spec(layers, card_edge, sides)
        check_order(spec, card_edge, sides)
        with open(os.path.join(fab, "order.json"), "w") as f:
            json.dump(spec, f, indent=2)
    step("fab order spec", order)

    def render():
        for side in ("top", "bottom"):
            run(["kicad-cli", "pcb", "render", "--width", "1200", "--height", "800", "--quality", "high",
                 "--side", side, "-o", os.path.join(out, "%s-%s.png" % (name, side)), pcb])
    step("3D render", render)
    # Provenance permits digital/power development with the existing offline
    # option. Bind its missing live-stock check to the generated artifacts so
    # stdout cannot be mistaken for manufacturing approval.
    import json
    with open(os.path.join(out, "pipeline-scope.json"), "w") as stream:
        json.dump({"version": 1,
                   "pipeline_mode": "development-offline" if state["stock_skipped"] else "live-stock-checked",
                   "live_stock_check": {"status": "skipped" if state["stock_skipped"] else "passed",
                                        "result": state["stock_result"]},
                   "manufacturing_release_approved": False,
                   "release_requirements": "doc/hardware/verification.md"}, stream, indent=2)
        stream.write("\n")
    boardevidence.record(name, out, evidence_inputs, boards)
    if state["stock_skipped"]:
        print("development outputs recorded; live stock skipped; manufacturing release remains open; outputs in", out)
    else:
        print("pipeline steps passed; remaining release checks in doc/hardware/verification.md; outputs in", out)
    return state["lcsc"]
