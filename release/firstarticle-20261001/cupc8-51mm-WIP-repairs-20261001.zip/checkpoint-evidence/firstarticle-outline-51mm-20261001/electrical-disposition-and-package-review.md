# 51 mm card revision: electrical disposition draft and package review

Engineering draft for root review, 2026-10-01. No purchase or supplier production approval is represented. Original final-E archive remains historical, unchanged. Acceptance remains Main + CPU + IO + storage + WiFi + either GPU/HDMI or selected eInk750, with System present for programming and removed for cold boot.

## IO USB: retain the explicit first-article condition

The genuine current-receipt-bound IC-007 run is **FAIL** for strict routed impedance. The old completed-B comparison uses the same numerical driver; its original receipt was independently validated, while its cross-tree diagnostic deliberately used `--no-evidence` and is not a release PASS. Neither report's budget was modified.

| Metric | Original completed B | Enlarged IO with relocated connector | Limit / assessment |
|---|---:|---:|---|
| MCU routed strict high-Z length | 15.425 mm | 15.425 mm | >99 ohm over this length; complete MCU impedance report exactly unchanged |
| MCU strict low-Z length | 0.607 mm | 0.607 mm | <81 ohm; unchanged |
| Connector strict high-Z length | 11.552 / 25.679 mm | 14.898 / 32.792 mm | Strict 90 ±10% design row fails both |
| Connector strict low-Z length | 4.506 mm | 4.109 mm | Strict design row fails both |
| USB 2.0 receptacle-to-RS high-Z length | 11.552 mm | 14.898 mm | >103.5 ohm; 90 ±15% condition fails both |
| Positive / negative total routed lengths | 26.684 / 33.030 mm | 30.234 / 36.580 mm | Each increased 3.550 mm |
| Intra-pair delay skew | 37.71 ps | 37.74 ps | <100 ps: pass |
| Longest delay upper bound | 236.3 ps | 261.7 ps | <3000 ps: pass |
| Modeled TL capacitance P / N | 5.450 / 7.488 pF | 5.785 / 8.053 pF | <75 pF model allocation: pass |
| Capacitance imbalance | 37.68% | 39.46% | Retain as numerical diagnostic; not an impedance pass |
| Figure 7-9 worst board-added edge time | 1.176 ns | 1.163 ns | Existing model edge checks pass |
| Figure 7-9 crossing voltage range | See baseline raw report | 1.654–1.684 V | Existing model checks pass |
| Figure 7-9 monotonic cases | All true | All true | Pass |
| Cable threshold cases | 32 / 32 clean | 32 / 32 clean | Pass within model scope |

The extension adds out-of-budget impedance length; it does not cure the existing mismatch. Modeled cable threshold behavior and edge timing show no demonstrated functional regression under the tested assumptions. They do not guarantee every physical keyboard, cable, host, package or temperature condition.

The prior user authorization is recorded in `doc/hardware/fab-waivers.md`: **IC-007 IO first-article routed-pair acceptance, David 2026-09-29**, with physical keyboard enumeration/transfers required and an explicit statement that acceptance is not an electrical pass. The later quote “accept it for now and note it as a possible issue” belongs specifically to **YC-007 System USB**, dated 2026-09-30; it must not be silently presented as a new IO hardware acceptance. The user additionally authorized reasonable engineering decisions toward first articles and the current size/connector change.

Recommendation to root: retain the new IO connector geometry for controlled first articles with an explicit updated engineering disposition citing the above comparison and the original IO condition. Preserve IC-007 FAIL in the proof index. This recommendation is a proposed current-revision disposition, not a fabricated user signature. Possible real fault remains keyboard enumeration failure, intermittent disconnects or unreliable key transfers with some cable/device combinations; a later localized IO pair repair could be necessary.

Receiving: test the actual assembled IO card in the target populated machine; use the intended USB keyboard/cable, cold boots, repeated attach/remove, continuous typing and IRQ/status handling, and verify no lost/stuck keys or reset/disconnect. Where instruments permit, measure D+/D− at the receptacle and driver during enumeration and transfer, crossing/rise/fall/monotonic behavior and compare to the declared USB limits with uncertainty. Track device/cable identity and stop the receiving check on demonstrated functional failure. Existing current/rail monitoring and TPS2553/C25 hot-attach bounds remain in force. Physical testing is future evidence, not closed by the native IO transport assertions or these field models.

Sources: `qualification/io-usb-fs.json`, `qualification/io-old-new-SI-comparison.json`, `qualification/old-B-io-usb-diagnostic.json`, `qualification/old-B-independent-receipt-validation.json`, `qualification/targeted-si-invocations.json`.

## GPU: repair the observed geometry regression

The first enlarged GPU's genuine GC-007 run fails because **7.02 mm combined conductor trace length per lane** is proven above 110 ohm. The old-B same-model diagnostic has no proven out-of-range trace; it retains only a clock-lane 0.461 mm upper-estimate undecided region. Thus the new high-Z extension is an actual numerical regression, not a historical failure to waive.

Eight matched straight connector-tail tracks originally 0.25 mm were widened locally to **0.28 mm** in the separate `gpu-tail-028-source-tree` candidate. All endpoints, lengths, pair centers, pin numbers, footprints, mounting positions and finger geometry are preserved. Actual isolated new-copper probes have bounds **103.64–106.52 ohm**, providing margin inside 90–110 ohm. Full model diagnostic on the actual 0.28 mm PCB has all electrical budgets positive:

| Lane | Trace lower-bound Z range (ohm) | Skew (ps) | Worst line return loss (dB) | Worst ESD return loss (dB) | Worst insertion loss (dB) |
|---|---:|---:|---:|---:|---:|
| D2 | 96.18–104.52 | 0.288 | −42.424 | −18.060 | −0.1672 |
| D1 | 90.34–108.61 | 0.681 | −40.736 | −17.886 | −0.1746 |
| D0 | 91.08–108.78 | 0.139 | −40.634 | −17.874 | −0.1762 |
| CK | 92.25–108.64 | 4.123 | −40.806 | −17.926 | −0.1747 |

Limits: 90–110 ohm including the driver's upper estimate check; skew <5 ps; line return loss ≤−19.58 dB; ESD return loss ≤−15 dB; insertion loss ≥−0.5 dB. Resistors remain 360 ohm from the actual netlist; modeled sink swing 215.2 mV minimum and 939.3 mV maximum pp are inside the declared 150–1200 mV condition.

At preparation of this draft, root's final current-receipt-bound run **56538**, output `qualification/gpu-tmds-028-final-bound.json`, is pending. The diagnostic's intentional `--no-evidence` makes its overall status FAIL despite positive electrical calculations; it must not be labeled a bound qualification PASS. Update this row only from the actual terminal bound result. The genuine normal 0.28 mm builder and full fab gate have passed; fresh 13-part engineering placement review is signed Codex and bound to the current receipt.

Receiving still requires actual HDMI display/sink/cable testing, cold boot, HPD/DDC compatibility and sustained output with rail/current/thermal monitoring under the existing GPU overclock and temperature conditions. The PCB model omits connector metal, cable/sink detail, package behavior and some coupling; this draft does not replace these known boundaries or claim physical HDMI certification.

Sources: `qualification/gpu-tmds.json`, `gpu-width-trials/isolated-tail-Z.json`, `gpu-width-trials/full-TMDS-028-diagnostic.json`, `qualification/gpu-028-full-fab.json`, `gpu-028-placement-review/actual-pad-pose-BOM-CPL-equality.json`, and final bound report when terminal.

## Package completeness observed at this checkpoint

`candidate-draft/STAGING-STATUS.json` explicitly says DRAFT. It has eight Gerber/drill ZIPs, BOM/CPL/order/review files and renders, plus current-board receipts. It is not yet a complete replacement for the final-E handoff.

Concrete remaining packaging actions:

1. Restage GPU from **gpu-tail-028-source-tree**, whose fresh receipt is `ca2a3a09c2a5fc8db8a36b005a50d16cd0054da2b42064291e1841afd8a36782`; the current draft still records enlarged 0.25 mm GPU receipt `c3d5bfe2...`. Use a recorded board-to-source map and validate each source independently. Any subsequent storage repaired fork likewise requires its own current receipt/review/qualification and staged bytes.
2. Add the actual final GPU bound TMDS proof, full fab/review/equality proof, mechanical carry/current proof, strict DC/current source receipts, interface clock/geometry evidence and this root-approved electrical disposition. Preserve failed first enlargement and diagnostic/baseline reports as provenance; never replace their verdicts.
3. Amend human ordering instructions to **Single PCB** for the enlarged six cards, with supplier-added temporary ≥5 mm assembly rails clear of fingers and perimeter access, removal before delivery, ENIG, 30° bevel and ±0.1 mm outline. Existing per-card order JSON still has `cards_per_panel:1` and no delivery-format field; an explicit updated companion instruction is needed to avoid sending the user back into the 70 ×70 mm V-cut panel form. Update seven card thickness acceptance to **1.44–1.70 mm** while preserving qualified stackups. Avoid modifying receipt-bound order files in place after builders: change source and rebuild or deliver a separately bound ordering supplement with an explicit supplier instruction amendment.
4. Record actual Main/System unchanged physical geometry and current Gerber/BOM/CPL byte comparison against prior final E. They need fresh source-bound receipts due shared-source changes, but an unchanged Main cart can be preserved only where its actual manufacturing bytes and user-selected settings agree. The user has now asked to redo Main/System anyway; guide new quotes with their existing board sizes. Main has no fingers, left/right rails only; System remains 56 ×56.4 mm and requires finger bevel/tolerance. Do not imply System enlarged to 51 mm.
5. Add final-E programming assets and quickstart, with exact hashes and the existing unchanged software source bridge. Preserve genuine E functional results as carried software proof, not fresh physical-card validation. Include the selected eInk750 panel instructions, storage media format, SysCtl/ROM program/readback and cold System removal procedure.
6. Add updated acceptance/proof index, engineering risk decision, receiving plan/parser, supplier options, external parts and actual quantities. Preserve quantity two assemblies per eight types, top+bottom for WiFi/eInk, Top for the others and actual My Parts FPGA sourcing authorization. No new purchase authorization is invented.
7. Build a uniquely named final archive, verify every file and ZIP member hash, eight current receipts, BOM/CPL/review/quantity/order identity and current source-map; independent audit after final package mutations. Commit/push source and the final reviewed artifact. Preserve the original `cupc8-firstarticle-QUALIFIED-development-E.zip`.

Factory CAM, placement preview, rail/bevel process and thickness confirmation remain real supplier actions after upload. Current component stock snapshots are dated and not reservations. Receiving gates requiring physical boards remain pending.
