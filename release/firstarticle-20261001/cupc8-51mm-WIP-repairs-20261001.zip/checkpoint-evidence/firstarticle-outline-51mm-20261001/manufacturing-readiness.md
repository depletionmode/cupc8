# Revised card manufacturing readiness

Target: Main, System, CPU, IO, storage, WiFi, and both display choices (GPU/HDMI and selected eInk750). Preserve the original qualified-development-E archive. The six row cards must have the full 62 × 51 mm outline with their top perimeter parts and support holes moved upward 3.55 mm; finger seating and notch stay fixed.

| Requirement | Current evidence | Remaining action |
|---|---|---|
| All eight normal builds and live stock | Baseline enlarged snapshot: eight genuine qty2 receipts | New GPU build passed; storage repair needs its own fresh build |
| Current placement and fabrication review | Baseline enlarged snapshot: 127 decisions and eight complete fab checks | Refresh affected repaired boards only after their final builds |
| Actual mechanical fit | All MECH-001 through MECH-008 passed | GPU exact 59-shape BREP carry passed; additional storage parts require actual fit review |
| GPU HDMI routed signal integrity | Extended original tails exceeded 110 Ω | Qualify actual widened 0.28 mm tails against fresh receipt |
| IO USB | Actual functional transient model passed 32/32 cable cases | Preserve strict impedance residual in explicit development decision |
| Storage SD | Existing model faults worsened after socket move | Qualify actual four 47 Ω resistors and 10 MHz request / 8.928571 MHz actual clock; rebuild and verify affected firmware |
| Selected eInk750 | Actual clock timing margins pass | Resolve or explicitly disposition analog ringing after resistor trials |
| Digital connectivity | 992 paths, 535 nets passed on enlarged baseline | Verify changed storage nets and any adopted component changes |
| Source and firmware provenance | Existing 207 compiled-source carry identities checked | Amend carry for storage firmware change and bind newly compiled delivery asset |
| Order instructions | Single PCB, temporary removable rails, 30° finger bevel, finished connector thickness 1.44–1.70 mm | Bind instructions to final board outputs and preserve Main/System order compatibility |
| Final archive and repository | Original E retained; WIP source checkpoint pushed | Adopt qualified repairs, stage final bytes, independently audit archive, commit and push |

No draft archive constitutes manufacturing approval. Manufacturing CAM approval and physical receiving measurements remain explicit first-article steps. No enclosure CAD was supplied; the new card support rail and enclosure headroom rise 3.55 mm.
