"""Package the freshly compiled and functionally checked storage ELF."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,shutil
D=Path(__file__).resolve().parent
R=D/'source-tree'
B=D/'delivery/rp2040';B.mkdir(parents=True,exist_ok=True)
parser=R/'tools/cupc8.py'
spec=importlib.util.spec_from_file_location('storage_release_flash',parser)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((D/'storage-firmware-functional-qualification.json').read_text())
elf=B/'storage.elf';shutil.copy2(R/'build/rp2040/storage.elf',elf)
assert h(elf)==proof['elf_sha256'] and proof['status']=='PASS'
image=module.elf_to_flash(elf.read_bytes());binary=B/'storage.bin';binary.write_bytes(image)
uf2=B/'storage.uf2';cmd=['/usr/bin/picotool','uf2','convert',str(elf),'-t','elf',str(uf2),'--family','rp2040']
run=subprocess.run(cmd,check=True,capture_output=True,text=True)
data=uf2.read_bytes();assert len(data)%512==0
memory={};numbers=set();total=None
for at in range(0,len(data),512):
 block=data[at:at+512];m1,m2,flags,address,size,index,count,family=struct.unpack_from('<8I',block)
 assert (m1,m2,struct.unpack_from('<I',block,508)[0])==(0x0A324655,0x9E5D5157,0x0AB16F30)
 assert flags&0x2000 and family==0xE48BFF56 and size<=476 and index not in numbers
 numbers.add(index);total=count if total is None else total;assert count==total
 for offset,value in enumerate(block[32:32+size]):
  key=address+offset;assert key not in memory or memory[key]==value;memory[key]=value
assert numbers==set(range(total))
assert bytes(memory[0x10000000+i] for i in range(len(image)))==image
out={'status':'PASS','scope':'Fresh storage ELF exact BIN and independently decoded official UF2 representation; hardware electrical qualification separate','functional_qualification_sha256':h(D/'storage-firmware-functional-qualification.json'),'host_parser_sha256':h(parser),'picotool_sha256':h(Path('/usr/bin/picotool')),'elf_sha256':h(elf),'bin_sha256':h(binary),'uf2_sha256':h(uf2),'flash_image_bytes':len(image),'UF2_blocks':total,'UF2_family':'RP2040 0xe48bff56','payload_exact':True,'command':cmd}
(D/'storage-flash-packaging-qualification.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS new storage ELF/BIN/UF2 payload identity')
